package com.chessassistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import java.io.File

class MainActivity : ComponentActivity() {

    private lateinit var info: TextView
    private lateinit var toggle: Switch
    private var updating = false

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { requestProjection() }

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val data = res.data
            if (res.resultCode == Activity.RESULT_OK && data != null) {
                val i = Intent(this, OverlayService::class.java)
                    .setAction(OverlayService.ACTION_START)
                    .putExtra(OverlayService.EXTRA_RESULT_CODE, res.resultCode)
                    .putExtra(OverlayService.EXTRA_DATA, data)
                ContextCompat.startForegroundService(this, i)
                Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 700)
            } else {
                Toast.makeText(this, "Screen capture permission was denied.", Toast.LENGTH_LONG).show()
                refresh()
            }
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }
        col.addView(TextView(this).apply {
            text = "Chess Assistant"; textSize = 26f; typeface = Typeface.DEFAULT_BOLD
        })
        col.addView(TextView(this).apply {
            text = "Floating study aid: shows Stockfish's best move as a green arrow over a chessboard on your screen."
            textSize = 14f; setPadding(0, dp(6), 0, dp(14))
        })

        toggle = Switch(this).apply {
            text = "Enable floating assistant"; textSize = 18f
            setOnCheckedChangeListener { _, checked ->
                if (updating) return@setOnCheckedChangeListener
                if (checked) beginEnable() else stopService(Intent(this@MainActivity, OverlayService::class.java))
                refresh()
            }
        }
        col.addView(toggle)

        info = TextView(this).apply { textSize = 14f; setPadding(0, dp(16), 0, dp(16)) }
        col.addView(info)

        col.addView(TextView(this).apply {
            textSize = 14f
            text = """
First-time setup
1. Open your chess app and show the board in the STARTING position (e.g. an analysis board).
2. Switch the assistant on above and grant the prompts.
3. Long-press the floating bubble, tap "Set board area", line the green grid up with the squares, Save.
4. Long-press the bubble > "Learn pieces". Do this once per piece theme / board size.
5. Any time later: tap the bubble to analyse. Drag it to move it. Long-press for the menu.

Bubble colour = who is better: white = White, black = Black, grey = equal. The number is the evaluation in pawns (+M3 = White mates in 3).

Permissions explained
- Display over other apps: draws the bubble, arrow and menu on top of other apps.
- Screen capture (system dialog): lets the app take screenshots of the board. Nothing is stored or uploaded.
- Foreground service: Android requires it for screen capture to keep working.
- Notifications: Android 13 needs this to show the "assistant is running" notification (with a Stop button).
- No internet permission: Stockfish runs entirely on your phone.

Please use it for study and analysis, not in rated games against other people.
""".trimIndent()
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun beginEnable() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Allow \"Display over other apps\", then come back and switch the assistant on again.",
                Toast.LENGTH_LONG
            ).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        requestProjection()
    }

    private fun requestProjection() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private fun refresh() {
        updating = true
        toggle.isChecked = OverlayService.running
        updating = false

        val prefs = Prefs(this)
        val notif = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        val engineOk = File(applicationInfo.nativeLibraryDir, "libstockfish.so").exists()
        val learned = File(filesDir, "templates.json").exists()
        fun mark(b: Boolean) = if (b) "\u2714" else "\u2718"
        info.text = """
${mark(Settings.canDrawOverlays(this))} Display over other apps
${mark(notif)} Notifications
${mark(engineOk)} Stockfish engine ${if (engineOk) "found" else "MISSING - see README step 2"}
${mark(prefs.hasBoard)} Board area ${if (prefs.hasBoard) "set" else "not set yet"}
${mark(learned)} Pieces ${if (learned) "learned" else "not learned yet"}
${mark(OverlayService.running)} Assistant ${if (OverlayService.running) "running" else "stopped"}
""".trimIndent()
    }
}
