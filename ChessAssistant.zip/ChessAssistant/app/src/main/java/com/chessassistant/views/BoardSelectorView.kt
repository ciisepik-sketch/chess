package com.chessassistant.views

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max

/** Draggable / resizable square with an 8x8 grid, used to mark where the chessboard is on screen. */
class BoardSelectorView(context: Context, initial: RectF) : View(context) {

    private val rect = RectF(initial)
    private val density = resources.displayMetrics.density
    private val handleR = 22f * density
    private val minSize = 160f * density

    private val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF00E676.toInt(); style = Paint.Style.STROKE; strokeWidth = 3f * density
    }
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xAA00E676.toInt(); strokeWidth = 1.2f * density
    }
    private val handle = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val handleRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF00C853.toInt(); style = Paint.Style.STROKE; strokeWidth = 3f * density
    }
    private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); textSize = 14f * density; setShadowLayer(4f, 0f, 0f, 0xFF000000.toInt())
    }

    private enum class Mode { NONE, MOVE, TL, BR }
    private var mode = Mode.NONE
    private var lastX = 0f
    private var lastY = 0f

    fun screenRect(): RectF {
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        return RectF(rect).apply { offset(loc[0].toFloat(), loc[1].toFloat()) }
    }

    override fun onDraw(c: Canvas) {
        c.drawText("Drag to move, drag a corner to resize.", 16f * density, 90f * density, hint)
        c.drawText("Make the grid match the 64 squares exactly.", 16f * density, 112f * density, hint)
        c.drawRect(rect, frame)
        val s = rect.width() / 8f
        for (i in 1..7) {
            c.drawLine(rect.left + i * s, rect.top, rect.left + i * s, rect.bottom, grid)
            c.drawLine(rect.left, rect.top + i * s, rect.right, rect.top + i * s, grid)
        }
        c.drawCircle(rect.left, rect.top, handleR, handle)
        c.drawCircle(rect.left, rect.top, handleR, handleRing)
        c.drawCircle(rect.right, rect.bottom, handleR, handle)
        c.drawCircle(rect.right, rect.bottom, handleR, handleRing)
    }

    private fun near(x: Float, y: Float, px: Float, py: Float) =
        abs(x - px) < handleR * 1.6f && abs(y - py) < handleR * 1.6f

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x; lastY = e.y
                mode = when {
                    near(e.x, e.y, rect.left, rect.top) -> Mode.TL
                    near(e.x, e.y, rect.right, rect.bottom) -> Mode.BR
                    rect.contains(e.x, e.y) -> Mode.MOVE
                    else -> Mode.NONE
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - lastX; val dy = e.y - lastY
                lastX = e.x; lastY = e.y
                when (mode) {
                    Mode.MOVE -> rect.offset(dx, dy)
                    Mode.BR -> {
                        val size = max(minSize, rect.width() + (dx + dy) / 2f)
                        rect.right = rect.left + size; rect.bottom = rect.top + size
                    }
                    Mode.TL -> {
                        val size = max(minSize, rect.width() - (dx + dy) / 2f)
                        rect.left = rect.right - size; rect.top = rect.bottom - size
                    }
                    Mode.NONE -> {}
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { mode = Mode.NONE; return true }
        }
        return true
    }
}
