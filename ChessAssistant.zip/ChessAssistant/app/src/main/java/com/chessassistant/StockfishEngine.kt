package com.chessassistant

import android.content.Context
import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.BufferedWriter
import java.io.File
import java.io.IOException
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Runs the Stockfish executable as a child process and talks UCI to it.
 * The executable must be packaged as app/src/main/jniLibs/arm64-v8a/libstockfish.so
 * (Android only allows executing files from the app's native library directory).
 */
class StockfishEngine(private val context: Context) {

    data class Result(val bestMove: String?, val cp: Int?, val mate: Int?)

    private var process: Process? = null
    private var writer: BufferedWriter? = null
    private val lines = LinkedBlockingQueue<String>()
    private val mutex = Mutex()

    private val binary: File get() = File(context.applicationInfo.nativeLibraryDir, "libstockfish.so")

    fun isAvailable(): Boolean = binary.exists()

    private fun send(cmd: String) {
        val w = writer ?: throw IOException("Engine not running")
        w.write(cmd); w.write("\n"); w.flush()
    }

    private fun waitFor(prefix: String, timeoutMs: Long, onLine: ((String) -> Unit)? = null): String? {
        val deadline = SystemClock.elapsedRealtime() + timeoutMs
        while (true) {
            val remaining = deadline - SystemClock.elapsedRealtime()
            if (remaining <= 0) return null
            val line = lines.poll(remaining, TimeUnit.MILLISECONDS) ?: return null
            onLine?.invoke(line)
            if (line.startsWith(prefix)) return line
        }
    }

    private fun ensureStarted() {
        if (process?.isAlive == true) return
        if (!binary.exists()) {
            throw IOException("Stockfish binary missing. Copy it to app/src/main/jniLibs/arm64-v8a/libstockfish.so and rebuild (see README).")
        }
        lines.clear()
        val p = ProcessBuilder(binary.absolutePath).redirectErrorStream(true).start()
        process = p
        writer = p.outputStream.bufferedWriter()
        Thread {
            try {
                p.inputStream.bufferedReader().forEachLine { lines.put(it) }
            } catch (_: Exception) { }
        }.apply { isDaemon = true }.start()

        send("uci")
        if (waitFor("uciok", 10_000) == null) { stop(); throw IOException("Stockfish did not respond to UCI") }
        send("setoption name Threads value 2")
        send("setoption name Hash value 32")
        send("isready")
        if (waitFor("readyok", 10_000) == null) { stop(); throw IOException("Stockfish did not become ready") }
    }

    /** Scores in the result are from the point of view of the side to move. */
    suspend fun analyse(fen: String, moveTimeMs: Int): Result = mutex.withLock {
        withContext(Dispatchers.IO) {
            ensureStarted()
            lines.clear()
            var cp: Int? = null
            var mate: Int? = null
            send("position fen $fen")
            send("go movetime $moveTimeMs")
            val end = waitFor("bestmove", moveTimeMs + 8000L) { l ->
                if (l.startsWith("info") && l.contains(" score ") && !l.contains("bound")) {
                    val t = l.split(" ")
                    val i = t.indexOf("score")
                    val v = t.getOrNull(i + 2)?.toIntOrNull()
                    if (i >= 0 && v != null) {
                        when (t.getOrNull(i + 1)) {
                            "cp" -> { cp = v; mate = null }
                            "mate" -> { mate = v; cp = null }
                        }
                    }
                }
            }
            if (end == null) { stop(); throw IOException("Stockfish timed out") }
            val best = end.split(" ").getOrNull(1)
            Result(if (best == null || best == "(none)" || best == "0000") null else best, cp, mate)
        }
    }

    fun stop() {
        try { writer?.let { it.write("quit\n"); it.flush() } } catch (_: Exception) { }
        try { process?.destroy() } catch (_: Exception) { }
        process = null
        writer = null
    }
}
