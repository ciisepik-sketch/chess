package com.chessassistant

import android.content.Context
import android.graphics.Bitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/*
 * Theme-independent board recognition without a neural network:
 *
 *  1. The board crop is scaled to 768x768 (96 px per square).
 *  2. For every square the empty-square background colour is estimated from the four corners (median).
 *  3. Pixels that differ from that background form a mask; the mask is dilated, holes are filled
 *     (flood fill from the outside) and only the largest blob is kept -> a piece SILHOUETTE that does
 *     not depend on whether the square is light or dark, or highlighted.
 *  4. Piece TYPE = nearest silhouette template (learned from the starting position, 16x16, shift tolerant).
 *  5. Piece COLOUR = median brightness of the silhouette vs. a midpoint learned from the starting position.
 *
 * Because templates are learned from YOUR chess app's piece set, any piece set works as long as
 * you run "Learn pieces" once with the board in the starting position.
 */

private const val SQ = 96
private const val BOARD_PX = SQ * 8
private const val MARGIN = 10          // ignore the outer 10 px of each square (coordinates, borders)
private const val G = 32               // working grid per square
private const val PG = 16              // pooled grid used for matching
private const val COLOR_DIST_SQ = 40 * 40
private const val MIN_AREA = 90        // cells (of 1024) needed to count a square as occupied

private class SquareInfo(val area: Int, val sil: FloatArray, val lum: Float)

private fun blur(a: FloatArray): FloatArray {
    val out = FloatArray(PG * PG)
    for (y in 0 until PG) for (x in 0 until PG) {
        var s = 0f
        for (dy in -1..1) for (dx in -1..1) {
            val yy = y + dy; val xx = x + dx
            if (yy in 0 until PG && xx in 0 until PG) s += a[yy * PG + xx]
        }
        out[y * PG + x] = s / 9f
    }
    return out
}

private class Templates(val raw: Array<FloatArray>, val lumMid: Float) {
    val blurred: Array<FloatArray> = Array(raw.size) { blur(raw[it]) }
}

class BoardRecognizer(context: Context) {

    private val file = File(context.filesDir, "templates.json")
    private var templates: Templates? = null

    init { load() }

    fun isTrained(): Boolean = templates != null

    private val backRank = arrayOf(
        PieceType.ROOK, PieceType.KNIGHT, PieceType.BISHOP, PieceType.QUEEN,
        PieceType.KING, PieceType.BISHOP, PieceType.KNIGHT, PieceType.ROOK
    )

    private fun startPiece(rank: Int, file: Int): Piece? = when (rank) {
        0 -> Piece(backRank[file], true)
        1 -> Piece(PieceType.PAWN, true)
        6 -> Piece(PieceType.PAWN, false)
        7 -> Piece(backRank[file], false)
        else -> null
    }

    private fun pixelsOf(board: Bitmap): IntArray {
        val scaled = if (board.width == BOARD_PX && board.height == BOARD_PX) board
        else Bitmap.createScaledBitmap(board, BOARD_PX, BOARD_PX, true)
        val px = IntArray(BOARD_PX * BOARD_PX)
        scaled.getPixels(px, 0, BOARD_PX, 0, 0, BOARD_PX, BOARD_PX)
        if (scaled !== board) scaled.recycle()
        return px
    }

    private fun analyse(px: IntArray, sx: Int, sy: Int): SquareInfo {
        // 1. background colour from corner patches (median is robust to coordinate labels)
        val rs = IntArray(256); val gs = IntArray(256); val bs = IntArray(256)
        var n = 0
        val offs = intArrayOf(3, SQ - 3 - 8)
        for (oy in offs) for (ox in offs) for (y in 0 until 8) for (x in 0 until 8) {
            val c = px[(sy + oy + y) * BOARD_PX + sx + ox + x]
            rs[n] = (c shr 16) and 255; gs[n] = (c shr 8) and 255; bs[n] = c and 255; n++
        }
        rs.sort(); gs.sort(); bs.sort()
        val br = rs[n / 2]; val bg = gs[n / 2]; val bb = bs[n / 2]

        // 2. mask of pixels that differ from the background
        val inner = SQ - 2 * MARGIN
        val mask = BooleanArray(G * G)
        val lum = FloatArray(G * G)
        for (gy in 0 until G) {
            val py = sy + MARGIN + ((2 * gy + 1) * inner) / (2 * G)
            for (gx in 0 until G) {
                val pxx = sx + MARGIN + ((2 * gx + 1) * inner) / (2 * G)
                val c = px[py * BOARD_PX + pxx]
                val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
                val dr = r - br; val dg = g - bg; val db = b - bb
                mask[gy * G + gx] = dr * dr + dg * dg + db * db > COLOR_DIST_SQ
                lum[gy * G + gx] = 0.299f * r + 0.587f * g + 0.114f * b
            }
        }

        // 3a. dilate by one cell (closes thin gaps in outlines)
        val dil = BooleanArray(G * G)
        for (y in 0 until G) for (x in 0 until G) {
            if (!mask[y * G + x]) continue
            for (dy in -1..1) for (dx in -1..1) {
                val ny = y + dy; val nx = x + dx
                if (ny in 0 until G && nx in 0 until G) dil[ny * G + nx] = true
            }
        }

        // 3b. flood fill the outside from the border; whatever is not outside is the silhouette
        val outside = BooleanArray(G * G)
        val queue = IntArray(G * G)
        var qh = 0
        var qt = 0
        fun push(i: Int) {
            if (!dil[i] && !outside[i]) { outside[i] = true; queue[qt++] = i }
        }
        for (i in 0 until G) { push(i); push((G - 1) * G + i); push(i * G); push(i * G + G - 1) }
        while (qh < qt) {
            val i = queue[qh++]; val y = i / G; val x = i % G
            if (y > 0) push(i - G)
            if (y < G - 1) push(i + G)
            if (x > 0) push(i - 1)
            if (x < G - 1) push(i + 1)
        }

        // 3c. keep only the largest connected blob (drops stray coordinate letters etc.)
        val comp = IntArray(G * G)
        var best = 0; var bestId = 0; var id = 0
        fun visit(j: Int, cid: Int) {
            if (!outside[j] && comp[j] == 0) { comp[j] = cid; queue[qt++] = j }
        }
        for (s in 0 until G * G) {
            if (outside[s] || comp[s] != 0) continue
            id++
            var size = 0
            qh = 0; qt = 0
            comp[s] = id; queue[qt++] = s
            while (qh < qt) {
                val i = queue[qh++]; size++
                val y = i / G; val x = i % G
                if (y > 0) visit(i - G, id)
                if (y < G - 1) visit(i + G, id)
                if (x > 0) visit(i - 1, id)
                if (x < G - 1) visit(i + 1, id)
            }
            if (size > best) { best = size; bestId = id }
        }
        if (best < MIN_AREA) return SquareInfo(best, FloatArray(PG * PG), 0f)

        val sil = FloatArray(PG * PG)
        for (y in 0 until PG) for (x in 0 until PG) {
            var c = 0
            for (dy in 0..1) for (dx in 0..1) if (comp[(2 * y + dy) * G + 2 * x + dx] == bestId) c++
            sil[y * PG + x] = c / 4f
        }
        val lums = FloatArray(best)
        var k = 0
        for (i in 0 until G * G) if (comp[i] == bestId) lums[k++] = lum[i]
        lums.sort()
        return SquareInfo(best, sil, lums[best / 2])
    }

    private fun dist(q: FloatArray, t: FloatArray): Float {
        var best = Float.MAX_VALUE
        for (dy in -1..1) for (dx in -1..1) {
            var s = 0f
            for (y in 0 until PG) {
                val ty = y + dy
                for (x in 0 until PG) {
                    val tx = x + dx
                    val tv = if (ty in 0 until PG && tx in 0 until PG) t[ty * PG + tx] else 0f
                    val d = q[y * PG + x] - tv
                    s += d * d
                }
            }
            if (s < best) best = s
        }
        return best
    }

    /** Learn piece shapes from a board showing the STANDARD STARTING POSITION. Returns an error or null. */
    fun learn(board: Bitmap, whiteAtBottom: Boolean): String? {
        val px = pixelsOf(board)
        val sums = Array(6) { FloatArray(PG * PG) }
        val counts = IntArray(6)
        var wLum = 0f; var wN = 0; var bLum = 0f; var bN = 0
        var middleOccupied = 0
        for (row in 0..7) for (col in 0..7) {
            val file = if (whiteAtBottom) col else 7 - col
            val rank = if (whiteAtBottom) 7 - row else row
            val info = analyse(px, col * SQ, row * SQ)
            val expected = startPiece(rank, file)
            if (expected == null) {
                if (info.area >= MIN_AREA) middleOccupied++
                continue
            }
            if (info.area < MIN_AREA) {
                return "Square ${'a' + file}${rank + 1} looks empty. Is the board area aligned and the board in the starting position?"
            }
            val t = expected.type.ordinal
            for (i in sums[t].indices) sums[t][i] += info.sil[i]
            counts[t]++
            if (expected.white) { wLum += info.lum; wN++ } else { bLum += info.lum; bN++ }
        }
        if (middleOccupied > 3) return "Ranks 3-6 are not empty. The board must be in the starting position (and the board orientation setting must be right)."
        val whiteAvg = wLum / wN; val blackAvg = bLum / bN
        if (whiteAvg - blackAvg < 30f) return "Couldn't tell white pieces from black ones. Check the board orientation and board area."
        val raw = Array(6) { t -> FloatArray(PG * PG) { i -> sums[t][i] / counts[t] } }
        val t = Templates(raw, (whiteAvg + blackAvg) / 2f)
        templates = t
        save(t)
        return null
    }

    /** Returns a grid (index = rank*8+file) or null if the pieces haven't been learned yet. */
    fun recognize(board: Bitmap, whiteAtBottom: Boolean): Grid? {
        val t = templates ?: return null
        val px = pixelsOf(board)
        val grid = arrayOfNulls<Piece>(64)
        for (row in 0..7) for (col in 0..7) {
            val info = analyse(px, col * SQ, row * SQ)
            if (info.area < MIN_AREA) continue
            val q = blur(info.sil)
            var bestType = 0; var bestD = Float.MAX_VALUE
            for (ti in 0 until 6) {
                val d = dist(q, t.blurred[ti])
                if (d < bestD) { bestD = d; bestType = ti }
            }
            val file = if (whiteAtBottom) col else 7 - col
            val rank = if (whiteAtBottom) 7 - row else row
            grid[rank * 8 + file] = Piece(PieceType.values()[bestType], info.lum > t.lumMid)
        }
        return grid
    }

    private fun save(t: Templates) {
        val o = JSONObject()
        o.put("lum", t.lumMid.toDouble())
        val arr = JSONArray()
        for (s in t.raw) {
            val a = JSONArray()
            for (v in s) a.put(v.toDouble())
            arr.put(a)
        }
        o.put("sil", arr)
        file.writeText(o.toString())
    }

    private fun load() {
        try {
            if (!file.exists()) return
            val o = JSONObject(file.readText())
            val arr = o.getJSONArray("sil")
            val raw = Array(arr.length()) { i ->
                val a = arr.getJSONArray(i)
                FloatArray(a.length()) { j -> a.getDouble(j).toFloat() }
            }
            if (raw.size == 6) templates = Templates(raw, o.getDouble("lum").toFloat())
        } catch (_: Exception) {
            templates = null
        }
    }
}
