package com.chessassistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.view.WindowManager
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume

/** Takes one full-screen screenshot per call using an existing MediaProjection. */
class ScreenCapturer(
    private val context: Context,
    private val projection: MediaProjection,
    onStopped: () -> Unit
) {
    private val thread = HandlerThread("screen-capture").apply { start() }
    private val handler = Handler(thread.looper)

    init {
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { onStopped() }
        }, handler)
    }

    suspend fun capture(): Bitmap? = withTimeoutOrNull(3000) {
        suspendCancellableCoroutine<Bitmap?> { cont ->
            val wm = context.getSystemService(WindowManager::class.java)
            val bounds = wm.maximumWindowMetrics.bounds
            val w = bounds.width()
            val h = bounds.height()
            val dpi = context.resources.displayMetrics.densityDpi
            val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            val holder = arrayOfNulls<VirtualDisplay>(1)
            val finished = AtomicBoolean(false)

            fun finish(bmp: Bitmap?) {
                if (!finished.compareAndSet(false, true)) { bmp?.recycle(); return }
                try { holder[0]?.release() } catch (_: Exception) { }
                try { reader.close() } catch (_: Exception) { }
                if (cont.isActive) cont.resume(bmp) else bmp?.recycle()
            }

            reader.setOnImageAvailableListener({ r ->
                val img = try { r.acquireLatestImage() } catch (e: Exception) { null }
                if (img != null) {
                    val bmp = try { toBitmap(img, w, h) } catch (e: Exception) { null } finally { img.close() }
                    finish(bmp)
                }
            }, handler)

            holder[0] = projection.createVirtualDisplay(
                "chess-capture", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface, null, handler
            )
            if (finished.get()) { try { holder[0]?.release() } catch (_: Exception) { } }
            cont.invokeOnCancellation { handler.post { finish(null) } }
        }
    }

    private fun toBitmap(img: Image, w: Int, h: Int): Bitmap {
        val plane = img.planes[0]
        val pixelStride = plane.pixelStride
        val rowPadding = plane.rowStride - pixelStride * w
        val padded = Bitmap.createBitmap(w + rowPadding / pixelStride, h, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(plane.buffer)
        return if (padded.width == w) padded
        else Bitmap.createBitmap(padded, 0, 0, w, h).also { padded.recycle() }
    }

    fun release() {
        try { projection.stop() } catch (_: Exception) { }
        thread.quitSafely()
    }
}
