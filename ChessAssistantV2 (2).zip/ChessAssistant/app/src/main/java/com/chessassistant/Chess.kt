package com.chessassistant

enum class PieceType(val letter: Char) {
    PAWN('p'), KNIGHT('n'), BISHOP('b'), ROOK('r'), QUEEN('q'), KING('k')
}

data class Piece(val type: PieceType, val white: Boolean) {
    fun fenChar(): Char = if (white) type.letter.uppercaseChar() else type.letter
}

/** Index = rank * 8 + file. rank 0 = rank "1", file 0 = file "a". */
typealias Grid = Array<Piece?>

data class Move(val fromFile: Int, val fromRank: Int, val toFile: Int, val toRank: Int) {
    companion object {
        fun parse(uci: String): Move? {
            if (uci.length < 4) return null
            val m = Move(uci[0] - 'a', uci[1] - '1', uci[2] - 'a', uci[3] - '1')
            val all = intArrayOf(m.fromFile, m.fromRank, m.toFile, m.toRank)
            return if (all.all { it in 0..7 }) m else null
        }
    }
}

object Fen {
    fun placement(grid: Grid): String {
        val sb = StringBuilder()
        for (rank in 7 downTo 0) {
            var empty = 0
            for (file in 0..7) {
                val p = grid[rank * 8 + file]
                if (p == null) {
                    empty++
                } else {
                    if (empty > 0) { sb.append(empty); empty = 0 }
                    sb.append(p.fenChar())
                }
            }
            if (empty > 0) sb.append(empty)
            if (rank > 0) sb.append('/')
        }
        return sb.toString()
    }

    fun build(grid: Grid, whiteToMove: Boolean): String {
        fun at(file: Int, rank: Int) = grid[rank * 8 + file]
        val castling = StringBuilder()
        if (at(4, 0) == Piece(PieceType.KING, true)) {
            if (at(7, 0) == Piece(PieceType.ROOK, true)) castling.append('K')
            if (at(0, 0) == Piece(PieceType.ROOK, true)) castling.append('Q')
        }
        if (at(4, 7) == Piece(PieceType.KING, false)) {
            if (at(7, 7) == Piece(PieceType.ROOK, false)) castling.append('k')
            if (at(0, 7) == Piece(PieceType.ROOK, false)) castling.append('q')
        }
        if (castling.isEmpty()) castling.append('-')
        return "${placement(grid)} ${if (whiteToMove) "w" else "b"} $castling - 0 1"
    }

    /** Returns an error message if the position can't be legal, else null. */
    fun validate(grid: Grid): String? {
        val whiteKings = grid.count { it != null && it.type == PieceType.KING && it.white }
        val blackKings = grid.count { it != null && it.type == PieceType.KING && !it.white }
        if (whiteKings != 1 || blackKings != 1) return "expected one king per side (found $whiteKings white, $blackKings black)"
        for (i in 0..7) {
            val a = grid[i]; val b = grid[56 + i]
            if (a != null && a.type == PieceType.PAWN) return "pawn on the first rank"
            if (b != null && b.type == PieceType.PAWN) return "pawn on the last rank"
        }
        return null
    }
}
