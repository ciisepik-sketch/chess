package com.chessassistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import java.io.File

class MainActivity : ComponentActivity() {

    private val plum = 0xFF3B0A2A.toInt()
    private val pink = 0xFFE8478B.toInt()
    private val pinkLight = 0xFFFFB6D0.toInt()
    private val bg = 0xFFFF8FB8.toInt()

    private lateinit var info: TextView
    private lateinit var toggle: Switch
    private var updating = false

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { requestProjection() }

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val data = res.data
            if (res.resultCode == Activity.RESULT_OK && data != null) {
                val i = Intent(this, OverlayService::class.java)
                    .setAction(OverlayService.ACTION_START)
                    .putExtra(OverlayService.EXTRA_RESULT_CODE, res.resultCode)
                    .putExtra(OverlayService.EXTRA_DATA, data)
                ContextCompat.startForegroundService(this, i)
                Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 700)
            } else {
                Toast.makeText(this, "Screen capture permission was denied.", Toast.LENGTH_LONG).show()
                refresh()
            }
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(16), dp(18), dp(16))
        background = GradientDrawable().apply {
            setColor(0xFFFFFFFF.toInt()); cornerRadius = dp(22).toFloat(); setStroke(dp(1), pinkLight)
        }
    }

    private fun addCard(col: LinearLayout, c: LinearLayout) {
        col.addView(
            c,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(14) }
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(36), dp(20), dp(28))
        }
        col.addView(TextView(this).apply {
            text = "Cjs stockfish"; textSize = 30f; typeface = Typeface.DEFAULT_BOLD; setTextColor(plum)
        })
        col.addView(TextView(this).apply {
            text = "your pink chess helper \u265B"; textSize = 15f; setTextColor(plum)
        })

        val c1 = card()
        toggle = Switch(this).apply {
            text = "Enable floating assistant"; textSize = 18f; setTextColor(plum)
            val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            thumbTintList = ColorStateList(states, intArrayOf(pink, 0xFFBDBDBD.toInt()))
            trackTintList = ColorStateList(states, intArrayOf(pinkLight, 0xFFE0E0E0.toInt()))
            setOnCheckedChangeListener { _, checked ->
                if (updating) return@setOnCheckedChangeListener
                if (checked) beginEnable() else stopService(Intent(this@MainActivity, OverlayService::class.java))
                refresh()
            }
        }
        c1.addView(toggle)
        addCard(col, c1)

        val c2 = card()
        info = TextView(this).apply { textSize = 14f; setTextColor(plum) }
        c2.addView(info)
        addCard(col, c2)

        val c3 = card()
        c3.addView(TextView(this).apply {
            textSize = 14f; setTextColor(plum)
            text = "First-time setup\n" +
                "1. Open your chess app with the board in the STARTING position (no hints or arrows).\n" +
                "2. Switch the assistant on above and allow the prompts.\n" +
                "3. Hold the \u265B bubble, tap \"Set board area\", line the grid up with the squares, Save.\n" +
                "4. Hold the bubble again, tap \"Learn pieces\" (once per piece theme / board size).\n" +
                "5. Later: tap the bubble to analyse. Drag it to move it. Hold it for the menu.\n\n" +
                "Bubble colour: white = White is better, plum = Black is better, light pink = equal. " +
                "The number is the evaluation in pawns (+M3 = White mates in 3).\n\n" +
                "Permissions\n" +
                "- Display over other apps: draws the bubble, arrow and menu.\n" +
                "- Screen capture (system dialog): screenshots of the board. Nothing is stored or uploaded.\n" +
                "- Foreground service: Android needs it for screen capture.\n" +
                "- Notifications: Android 13 needs it for the \"running\" notification.\n" +
                "- No internet permission: Stockfish runs on your phone.\n\n" +
                "For study and practice, not rated games against real people."
        })
        addCard(col, c3)

        setContentView(ScrollView(this).apply { setBackgroundColor(bg); addView(col) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun beginEnable() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Allow \"Display over other apps\", then come back and switch the assistant on again.",
                Toast.LENGTH_LONG
            ).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        requestProjection()
    }

    private fun requestProjection() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private fun refresh() {
        updating = true
        toggle.isChecked = OverlayService.running
        updating = false

        val prefs = Prefs(this)
        val notif = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        val engineOk = File(applicationInfo.nativeLibraryDir, "libstockfish.so").exists()
        val learned = File(filesDir, "templates.json").exists()
        fun mark(b: Boolean) = if (b) "\u2714" else "\u2718"
        info.text = mark(Settings.canDrawOverlays(this)) + " Display over other apps\n" +
            mark(notif) + " Notifications\n" +
            mark(engineOk) + " Stockfish engine " + (if (engineOk) "found" else "MISSING") + "\n" +
            mark(prefs.hasBoard) + " Board area " + (if (prefs.hasBoard) "set" else "not set yet") + "\n" +
            mark(learned) + " Pieces " + (if (learned) "learned" else "not learned yet") + "\n" +
            mark(OverlayService.running) + " Assistant " + (if (OverlayService.running) "running" else "stopped")
    }
}
