package com.chessassistant

import kotlin.math.abs

/** One move: from-square, to-square (index = rank * 8 + file) and, for a pawn reaching the last row, what it becomes. */
class Mv(val from: Int, val to: Int, val promo: PieceType?)

/** One or two moves that turn one board into another. boards[i] is the board after moves[i]. */
class FoundChain(val moves: List<Mv>, val boards: List<Grid>, val mismatches: Int)

/** A small chess move generator, used to work out which moves were played between two looks at the board. */
object MoveGen {

    private val JUMPS = arrayOf(
        intArrayOf(1, 2), intArrayOf(2, 1), intArrayOf(-1, 2), intArrayOf(-2, 1),
        intArrayOf(1, -2), intArrayOf(2, -1), intArrayOf(-1, -2), intArrayOf(-2, -1)
    )

    private fun sq(file: Int, rank: Int) = rank * 8 + file

    private fun inside(file: Int, rank: Int) = file in 0..7 && rank in 0..7

    fun apply(grid: Grid, m: Mv): Grid {
        val g = grid.copyOf()
        val p = g[m.from] ?: return g
        if (p.type == PieceType.KING && abs(m.to % 8 - m.from % 8) == 2) {
            val rank = m.from / 8
            if (m.to % 8 == 6) {
                g[sq(5, rank)] = g[sq(7, rank)]
                g[sq(7, rank)] = null
            } else {
                g[sq(3, rank)] = g[sq(0, rank)]
                g[sq(0, rank)] = null
            }
        }
        if (p.type == PieceType.PAWN && m.from % 8 != m.to % 8 && g[m.to] == null) {
            // en passant: the captured pawn stands beside the moving pawn
            g[sq(m.to % 8, m.from / 8)] = null
        }
        val promo = m.promo
        g[m.to] = if (promo != null) Piece(promo, p.white) else p
        g[m.from] = null
        return g
    }

    private fun addPawnMove(out: MutableList<Mv>, from: Int, to: Int, promotes: Boolean) {
        if (!promotes) {
            out.add(Mv(from, to, null))
            return
        }
        out.add(Mv(from, to, PieceType.QUEEN))
        out.add(Mv(from, to, PieceType.ROOK))
        out.add(Mv(from, to, PieceType.BISHOP))
        out.add(Mv(from, to, PieceType.KNIGHT))
    }

    private fun pseudoMoves(grid: Grid, from: Int, p: Piece, out: MutableList<Mv>) {
        val f = from % 8
        val r = from / 8
        val white = p.white
        when (p.type) {
            PieceType.PAWN -> {
                val dir = if (white) 1 else -1
                val startRank = if (white) 1 else 6
                val lastRank = if (white) 7 else 0
                val nr = r + dir
                if (nr in 0..7) {
                    if (grid[sq(f, nr)] == null) {
                        addPawnMove(out, from, sq(f, nr), nr == lastRank)
                        if (r == startRank && grid[sq(f, r + 2 * dir)] == null) out.add(Mv(from, sq(f, r + 2 * dir), null))
                    }
                    for (df in intArrayOf(-1, 1)) {
                        val tf = f + df
                        if (tf !in 0..7) continue
                        val t = grid[sq(tf, nr)]
                        if (t != null && t.white != white) {
                            addPawnMove(out, from, sq(tf, nr), nr == lastRank)
                        } else if (t == null) {
                            // en passant (the last move isn't known, so any enemy pawn beside us counts)
                            val epRank = if (white) 4 else 3
                            val beside = grid[sq(tf, r)]
                            if (r == epRank && beside != null && beside.type == PieceType.PAWN && beside.white != white) {
                                out.add(Mv(from, sq(tf, nr), null))
                            }
                        }
                    }
                }
            }
            PieceType.KNIGHT -> {
                for (j in JUMPS) {
                    val tf = f + j[0]
                    val tr = r + j[1]
                    if (!inside(tf, tr)) continue
                    val t = grid[sq(tf, tr)]
                    if (t == null || t.white != white) out.add(Mv(from, sq(tf, tr), null))
                }
            }
            PieceType.KING -> {
                for (df in -1..1) for (dr in -1..1) {
                    if (df == 0 && dr == 0) continue
                    val tf = f + df
                    val tr = r + dr
                    if (!inside(tf, tr)) continue
                    val t = grid[sq(tf, tr)]
                    if (t == null || t.white != white) out.add(Mv(from, sq(tf, tr), null))
                }
                val home = if (white) 0 else 7
                if (r == home && f == 4 && !Rules.inCheck(grid, white)) {
                    val rookK = grid[sq(7, home)]
                    if (rookK != null && rookK.type == PieceType.ROOK && rookK.white == white &&
                        grid[sq(5, home)] == null && grid[sq(6, home)] == null &&
                        !Rules.inCheck(apply(grid, Mv(from, sq(5, home), null)), white)
                    ) {
                        out.add(Mv(from, sq(6, home), null))
                    }
                    val rookQ = grid[sq(0, home)]
                    if (rookQ != null && rookQ.type == PieceType.ROOK && rookQ.white == white &&
                        grid[sq(1, home)] == null && grid[sq(2, home)] == null && grid[sq(3, home)] == null &&
                        !Rules.inCheck(apply(grid, Mv(from, sq(3, home), null)), white)
                    ) {
                        out.add(Mv(from, sq(2, home), null))
                    }
                }
            }
            else -> {
                // bishop, rook, queen
                for (df in -1..1) for (dr in -1..1) {
                    if (df == 0 && dr == 0) continue
                    val straight = df == 0 || dr == 0
                    if (p.type == PieceType.ROOK && !straight) continue
                    if (p.type == PieceType.BISHOP && straight) continue
                    var cf = f + df
                    var cr = r + dr
                    while (inside(cf, cr)) {
                        val t = grid[sq(cf, cr)]
                        if (t != null && t.white == white) break
                        out.add(Mv(from, sq(cf, cr), null))
                        if (t != null) break
                        cf += df
                        cr += dr
                    }
                }
            }
        }
    }

    /** Every move the given side can legally make (castling and en passant are guessed from the board alone). */
    fun legalMoves(grid: Grid, white: Boolean): List<Mv> {
        val out = ArrayList<Mv>()
        for (from in 0..63) {
            val p = grid[from] ?: continue
            if (p.white != white) continue
            val candidates = ArrayList<Mv>()
            pseudoMoves(grid, from, p, candidates)
            for (m in candidates) {
                if (!Rules.inCheck(apply(grid, m), white)) out.add(m)
            }
        }
        return out
    }

    private fun name(square: Int) = "" + ('a' + square % 8) + ('1' + square / 8)

    /** Describes the move for the rating code. [grid] is the board BEFORE the move. */
    fun toDetected(grid: Grid, m: Mv): DetectedMove {
        val p = grid[m.from]!!
        val enPassant = p.type == PieceType.PAWN && m.from % 8 != m.to % 8 && grid[m.to] == null
        val captured = if (enPassant) grid[sq(m.to % 8, m.from / 8)] else grid[m.to]
        var uci = name(m.from) + name(m.to)
        val promo = m.promo
        if (promo != null) uci += promo.letter
        return DetectedMove(uci, p.white, m.from, m.to, p, captured)
    }
}

/** Works out which one or two moves were played between two looks at the board. */
object MoveFinder {

    private fun diff(a: Grid, b: Grid): Int {
        var n = 0
        for (i in 0..63) if (a[i] != b[i]) n++
        return n
    }

    /**
     * Tries every legal move (and every legal move followed by a reply) from [prev] and keeps the one that
     * best matches [now]. A couple of wrongly-read squares are tolerated. Returns null if nothing fits
     * or if two different answers fit equally well.
     */
    fun find(prev: Grid, prevWhite: Boolean, now: Grid): FoundChain? {
        var best: FoundChain? = null
        var bestKey = Int.MAX_VALUE
        var ambiguous = false

        fun consider(moves: List<Mv>, boards: List<Grid>, mismatches: Int) {
            val limit = if (moves.size == 1) 2 else 1
            if (mismatches > limit) return
            val key = mismatches * 10 + moves.size
            if (key < bestKey) {
                best = FoundChain(moves, boards, mismatches)
                bestKey = key
                ambiguous = false
            } else if (key == bestKey) {
                ambiguous = true
            }
        }

        for (m1 in MoveGen.legalMoves(prev, prevWhite)) {
            val g1 = MoveGen.apply(prev, m1)
            consider(listOf(m1), listOf(g1), diff(g1, now))
            for (m2 in MoveGen.legalMoves(g1, !prevWhite)) {
                val g2 = MoveGen.apply(g1, m2)
                consider(listOf(m1, m2), listOf(g1, g2), diff(g2, now))
            }
        }
        return if (ambiguous) null else best
    }
}
