package com.chessassistant

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max

/** The labels a move can get, in the style of Chess.com's game review. */
enum class MoveRating(val label: String, val mark: String, val colour: Int) {
    BRILLIANT("Brilliant", "!!", 0xFF1BACA6.toInt()),
    GREAT("Great", "!", 0xFF5C8BB0.toInt()),
    BEST("Best", "", 0xFF81B64C.toInt()),
    EXCELLENT("Excellent", "", 0xFF96BC4B.toInt()),
    GOOD("Good", "", 0xFF97AF8B.toInt()),
    BOOK("Book", "", 0xFFA88865.toInt()),
    INACCURACY("Inaccuracy", "?!", 0xFFE0B020.toInt()),
    MISTAKE("Mistake", "?", 0xFFE58F2A.toInt()),
    BLUNDER("Blunder", "??", 0xFFCA3431.toInt());

    fun chipText() = if (mark.isEmpty()) label else "$label $mark"

    /** The little symbol drawn on the board square of the move. */
    val badge: String
        get() = if (mark.isNotEmpty()) mark else when (this) {
            BEST -> "\u2605"
            EXCELLENT -> "+"
            GOOD -> "\u2713"
            BOOK -> "B"
            else -> ""
        }
}

/** What Stockfish thought of one position, always from the point of view of the side to move. */
class Snapshot(
    val grid: Grid,
    val whiteToMove: Boolean,
    val cp: Int?,
    val mate: Int?,
    val best: String?,
    val secondCp: Int?,
    val secondMate: Int?
)

/** A move worked out by comparing two boards. */
class DetectedMove(
    val uci: String,
    val white: Boolean,
    val from: Int,
    val to: Int,
    val piece: Piece,
    val captured: Piece?
)

class Review(
    val uci: String,
    val white: Boolean,
    val rating: MoveRating,
    val moveText: String,
    val explanation: String
)

object MoveReviewer {

    // ------------------------------------------------------------ small helpers

    private fun sqName(sq: Int) = "" + ('a' + sq % 8) + ('1' + sq / 8)

    private fun pieceName(t: PieceType) = when (t) {
        PieceType.PAWN -> "Pawn"
        PieceType.KNIGHT -> "Knight"
        PieceType.BISHOP -> "Bishop"
        PieceType.ROOK -> "Rook"
        PieceType.QUEEN -> "Queen"
        PieceType.KING -> "King"
    }

    private fun value(t: PieceType) = when (t) {
        PieceType.PAWN -> 1
        PieceType.KNIGHT -> 3
        PieceType.BISHOP -> 3
        PieceType.ROOK -> 5
        PieceType.QUEEN -> 9
        PieceType.KING -> 1000
    }

    private fun parseSq(s: String, i: Int): Int = (s[i] - 'a') + 8 * (s[i + 1] - '1')

    /** "Knight g1 to f3", "Queen h5 takes f7", "castles kingside"... */
    fun describe(grid: Grid, uci: String): String {
        if (uci.length < 4) return uci
        val from = parseSq(uci, 0)
        val to = parseSq(uci, 2)
        val p = grid.getOrNull(from) ?: return uci
        if (p.type == PieceType.KING && abs(from % 8 - to % 8) == 2) {
            return if (to % 8 == 6) "castles kingside" else "castles queenside"
        }
        val victim = grid[to]
        val enPassant = p.type == PieceType.PAWN && from % 8 != to % 8 && victim == null
        var s = if (victim != null || enPassant) "${pieceName(p.type)} ${sqName(from)} takes ${sqName(to)}"
        else "${pieceName(p.type)} ${sqName(from)} to ${sqName(to)}"
        if (uci.length >= 5) {
            val promo = when (uci[4]) { 'q' -> "Queen"; 'r' -> "Rook"; 'b' -> "Bishop"; 'n' -> "Knight"; else -> "" }
            if (promo.isNotEmpty()) s += " and becomes a $promo"
        }
        return s
    }

    // ------------------------------------------------------------ working out which move was played

    fun detect(before: Grid, after: Grid): DetectedMove? {
        val changed = (0..63).filter { before[it] != after[it] }
        when (changed.size) {
            2 -> {
                val a = changed[0]
                val b = changed[1]
                val from: Int
                val to: Int
                if (before[a] != null && after[a] == null) { from = a; to = b }
                else if (before[b] != null && after[b] == null) { from = b; to = a }
                else return null
                val mover = before[from] ?: return null
                val dest = after[to] ?: return null
                if (dest.white != mover.white) return null
                val captured = before[to]
                if (captured != null && captured.white == mover.white) return null
                var uci = sqName(from) + sqName(to)
                if (dest.type != mover.type) {
                    val lastRank = if (mover.white) 7 else 0
                    if (mover.type == PieceType.PAWN && to / 8 == lastRank && dest.type != PieceType.KING && dest.type != PieceType.PAWN) {
                        uci += dest.type.letter
                    } else return null
                }
                return DetectedMove(uci, mover.white, from, to, mover, captured)
            }
            3 -> {
                // en passant: our pawn leaves, lands on an empty square, and the enemy pawn beside it disappears
                val gone = changed.filter { before[it] != null && after[it] == null }
                val landed = changed.filter { before[it] == null && after[it] != null }
                if (gone.size != 2 || landed.size != 1) return null
                val to = landed[0]
                val mover = after[to] ?: return null
                if (mover.type != PieceType.PAWN) return null
                val from = gone.firstOrNull { before[it] == mover } ?: return null
                val capSq = gone.first { it != from }
                val cap = before[capSq] ?: return null
                if (cap.type != PieceType.PAWN || cap.white == mover.white) return null
                if (abs(from % 8 - to % 8) != 1) return null
                if (capSq / 8 != from / 8 || capSq % 8 != to % 8) return null
                return DetectedMove(sqName(from) + sqName(to), mover.white, from, to, mover, cap)
            }
            4 -> {
                for (white in listOf(true, false)) {
                    val base = if (white) 0 else 56
                    val king = Piece(PieceType.KING, white)
                    val rook = Piece(PieceType.ROOK, white)
                    val short = before[base + 4] == king && after[base + 6] == king &&
                        before[base + 7] == rook && after[base + 5] == rook &&
                        changed.toSet() == setOf(base + 4, base + 5, base + 6, base + 7)
                    if (short) return DetectedMove(sqName(base + 4) + sqName(base + 6), white, base + 4, base + 6, king, null)
                    val long = before[base + 4] == king && after[base + 2] == king &&
                        before[base] == rook && after[base + 3] == rook &&
                        changed.toSet() == setOf(base, base + 2, base + 3, base + 4)
                    if (long) return DetectedMove(sqName(base + 4) + sqName(base + 2), white, base + 4, base + 2, king, null)
                }
                return null
            }
            else -> return null
        }
        return null
    }

    // ------------------------------------------------------------ scores

    /** Turns an engine score into one number (centipawns), mate scores becoming huge. */
    private fun score(cp: Int?, mate: Int?): Int {
        if (mate != null) {
            return if (mate > 0) 10000 - mate else -10000 + abs(mate)
        }
        return cp ?: 0
    }

    /** Chances of winning, 0 to 100, for a score in centipawns (same curve Lichess uses). */
    private fun winPercent(cp: Int): Double {
        val c = cp.coerceIn(-1000, 1000)
        return 50.0 + 50.0 * (2.0 / (1.0 + exp(-0.00368208 * c)) - 1.0)
    }

    // ------------------------------------------------------------ captures on a square (for sacrifices)

    private fun attackerValues(grid: Grid, f: Int, r: Int, byWhite: Boolean): MutableList<Int> {
        val out = ArrayList<Int>()
        fun at(ff: Int, rr: Int): Piece? = if (ff in 0..7 && rr in 0..7) grid[rr * 8 + ff] else null
        val pawnRank = if (byWhite) r - 1 else r + 1
        for (df in intArrayOf(-1, 1)) {
            val p = at(f + df, pawnRank)
            if (p != null && p.white == byWhite && p.type == PieceType.PAWN) out.add(1)
        }
        val jumps = arrayOf(
            intArrayOf(1, 2), intArrayOf(2, 1), intArrayOf(-1, 2), intArrayOf(-2, 1),
            intArrayOf(1, -2), intArrayOf(2, -1), intArrayOf(-1, -2), intArrayOf(-2, -1)
        )
        for (j in jumps) {
            val p = at(f + j[0], r + j[1])
            if (p != null && p.white == byWhite && p.type == PieceType.KNIGHT) out.add(3)
        }
        for (df in -1..1) for (dr in -1..1) {
            if (df == 0 && dr == 0) continue
            val k = at(f + df, r + dr)
            if (k != null && k.white == byWhite && k.type == PieceType.KING) out.add(1000)
            val straight = df == 0 || dr == 0
            var cf = f + df
            var cr = r + dr
            while (cf in 0..7 && cr in 0..7) {
                val p = grid[cr * 8 + cf]
                if (p != null) {
                    if (p.white == byWhite) {
                        if (p.type == PieceType.QUEEN) out.add(9)
                        else if (straight && p.type == PieceType.ROOK) out.add(5)
                        else if (!straight && p.type == PieceType.BISHOP) out.add(3)
                    }
                    break
                }
                cf += df
                cr += dr
            }
        }
        out.sort()
        return out
    }

    /** How much material the side that does NOT own the piece on [sq] would win by capturing it (never below 0). */
    private fun captureGain(grid: Grid, sq: Int): Int {
        val target = grid[sq] ?: return 0
        val f = sq % 8
        val r = sq / 8
        val attackers = attackerValues(grid, f, r, !target.white)
        if (attackers.isEmpty()) return 0
        // The target itself is not one of its own defenders
        val defenders = attackerValues(grid, f, r, target.white)
        val gain = IntArray(40)
        var d = 0
        gain[0] = value(target.type)
        var onSquare = attackers[0]
        var ai = 1
        var di = 0
        var defenderTurn = true
        while (d < 38) {
            if (defenderTurn) {
                if (di >= defenders.size) break
                d++
                gain[d] = onSquare - gain[d - 1]
                onSquare = defenders[di++]
            } else {
                if (ai >= attackers.size) break
                d++
                gain[d] = onSquare - gain[d - 1]
                onSquare = attackers[ai++]
            }
            defenderTurn = !defenderTurn
        }
        while (d > 0) {
            gain[d - 1] = -max(-gain[d - 1], gain[d])
            d--
        }
        return max(0, gain[0])
    }

    // ------------------------------------------------------------ opening book

    private val bookLines = listOf(
        "e2e4 e7e5 g1f3 b8c6 f1b5 a7a6 b5a4 g8f6 e1g1 f8e7 f1e1 b7b5 a4b3 d7d6 c2c3 e8g8 h2h3 c6a5 b3c2 c7c5 d2d4 d8c7",
        "e2e4 e7e5 g1f3 b8c6 f1b5 a7a6 b5a4 g8f6 e1g1 f8e7 f1e1 b7b5 a4b3 e8g8 c2c3 d7d5 e4d5 f6d5 f3e5 c6e5 e1e5 c7c6",
        "e2e4 e7e5 g1f3 b8c6 f1b5 g8f6 e1g1 f6e4 d2d4 e4d6 b5c6 d7c6 d4e5 d6f5 d1d8 e8d8",
        "e2e4 e7e5 g1f3 b8c6 f1b5 a7a6 b5c6 d7c6 e1g1 f7f6 d2d4 e5d4 f3d4 c6c5 d4b3 d8d1 f1d1",
        "e2e4 e7e5 g1f3 b8c6 f1b5 a7a6 b5a4 g8f6 e1g1 f6e4 d2d4 b7b5 a4b3 d7d5 d4e5 c8e6",
        "e2e4 e7e5 g1f3 b8c6 f1b5 a7a6 b5a4 d7d6 c2c3 c8d7 d2d4 g8f6",
        "e2e4 e7e5 g1f3 b8c6 f1c4 f8c5 c2c3 g8f6 d2d4 e5d4 c3d4 c5b4",
        "e2e4 e7e5 g1f3 b8c6 f1c4 f8c5 c2c3 g8f6 d2d3 d7d6 e1g1 e8g8",
        "e2e4 e7e5 g1f3 b8c6 f1c4 g8f6 f3g5 d7d5 e4d5 c6a5 c4b5 c7c6 d5c6 b7c6 b5e2 h7h6 g5f3 e5e4",
        "e2e4 e7e5 g1f3 b8c6 f1c4 f8c5 b2b4 c5b4 c2c3 b4a5 d2d4 e5d4 e1g1",
        "e2e4 e7e5 g1f3 b8c6 d2d4 e5d4 f3d4 g8f6 d4c6 b7c6 e4e5 d8e7 d1e2 f6d5 c2c4",
        "e2e4 e7e5 g1f3 b8c6 d2d4 e5d4 f3d4 f8c5 d4b3 c5b6 a2a4 a7a6",
        "e2e4 e7e5 g1f3 g8f6 f3e5 d7d6 e5f3 f6e4 d2d4 d6d5 f1d3 f8e7 e1g1 b8c6 c2c4 c6b4",
        "e2e4 e7e5 g1f3 d7d6 d2d4 g8f6 b1c3 b8d7 f1c4 f8e7 e1g1 e8g8",
        "e2e4 e7e5 b1c3 g8f6 f2f4 d7d5 f4e5 f6e4 g1f3 f8e7 d2d4 e8g8 f1d3 f7f5",
        "e2e4 e7e5 f2f4 e5f4 g1f3 g7g5 h2h4 g5g4 f3e5 g8f6",
        "e2e4 e7e5 f2f4 f8c5 g1f3 d7d6 c2c3 g8f6",
        "e2e4 e7e5 g1f3 b8c6 b1c3 g8f6 f1b5 f8b4 e1g1 e8g8 d2d3 d7d6 c1g5 b4c3 b2c3 d8e7",
        "e2e4 e7e5 g1f3 b8c6 b1c3 g8f6 d2d4 e5d4 f3d4 f8b4 d4c6 b7c6 f1d3 d7d5 e4d5 c6d5 e1g1 e8g8",
        "e2e4 c7c5 g1f3 d7d6 d2d4 c5d4 f3d4 g8f6 b1c3 a7a6 c1e3 e7e5 d4b3 c8e6 f2f3 f8e7 d1d2 e8g8 e1c1",
        "e2e4 c7c5 g1f3 d7d6 d2d4 c5d4 f3d4 g8f6 b1c3 a7a6 f1e2 e7e5 d4b3 f8e7 e1g1 e8g8",
        "e2e4 c7c5 g1f3 d7d6 d2d4 c5d4 f3d4 g8f6 b1c3 g7g6 c1e3 f8g7 f2f3 e8g8 d1d2 b8c6 f1c4 c8d7 e1c1",
        "e2e4 c7c5 g1f3 b8c6 d2d4 c5d4 f3d4 g8f6 b1c3 e7e5 d4b5 d7d6 c1g5 a7a6 b5a3 b7b5 c3d5 f8e7 g5f6 e7f6 c2c4 b5b4",
        "e2e4 c7c5 g1f3 b8c6 d2d4 c5d4 f3d4 g8f6 b1c3 d7d6 f1e2 e7e6 e1g1 f8e7",
        "e2e4 c7c5 c2c3 g8f6 e4e5 f6d5 d2d4 c5d4 g1f3 b8c6 c3d4 d7d6 f1c4 d5b6 c4b3 d6e5",
        "e2e4 c7c5 g1f3 e7e6 d2d4 c5d4 f3d4 b8c6 b1c3 d8c7 c1e3 a7a6 f1e2 g8f6 e1g1",
        "e2e4 c7c5 b1c3 b8c6 g2g3 g7g6 f1g2 f8g7 d2d3 d7d6 c1e3",
        "e2e4 c7c5 d2d4 c5d4 c2c3 d4c3 b1c3 b8c6 g1f3 d7d6 f1c4 e7e6 e1g1 g8f6",
        "e2e4 c7c5 b1c3 b8c6 f2f4 g7g6 g1f3 f8g7 f1c4 e7e6 f4f5",
        "e2e4 c7c5 g1f3 e7e6 d2d4 c5d4 f3d4 a7a6 f1d3 g8f6 e1g1 d7d6 c2c4",
        "e2e4 c7c5 g1f3 b8c6 f1b5 g7g6 b5c6 b7c6 e1g1 f8g7 f1e1 g8f6 e4e5 f6d5",
        "e2e4 c7c5 g1f3 d7d6 f1b5 c8d7 b5d7 d8d7 c2c4 b8c6 b1c3 g8f6 d2d4 c5d4 f3d4",
        "e2e4 e7e6 d2d4 d7d5 b1c3 g8f6 c1g5 f8e7 e4e5 f6d7 g5e7 d8e7 f2f4 e8g8 g1f3 c7c5",
        "e2e4 e7e6 d2d4 d7d5 b1c3 f8b4 e4e5 c7c5 a2a3 b4c3 b2c3 g8e7 d1g4 d8c7 g4g7 h8g8 g7h7 c5d4",
        "e2e4 e7e6 d2d4 d7d5 b1d2 g8f6 e4e5 f6d7 f1d3 c7c5 c2c3 b8c6 g1e2 c5d4 c3d4 f7f6",
        "e2e4 e7e6 d2d4 d7d5 e4e5 c7c5 c2c3 b8c6 g1f3 d8b6 a2a3 c5c4",
        "e2e4 e7e6 d2d4 d7d5 e4d5 e6d5 g1f3 g8f6 f1d3 f8d6 e1g1 e8g8",
        "e2e4 c7c6 d2d4 d7d5 b1c3 d5e4 c3e4 c8f5 e4g3 f5g6 h2h4 h7h6 g1f3 b8d7 h4h5 g6h7 f1d3 h7d3 d1d3 e7e6",
        "e2e4 c7c6 d2d4 d7d5 e4e5 c8f5 g1f3 e7e6 f1e2 c6c5",
        "e2e4 c7c6 d2d4 d7d5 e4d5 c6d5 c2c4 g8f6 b1c3 e7e6 g1f3 f8e7 c4d5 f6d5 f1d3 b8c6",
        "e2e4 d7d6 d2d4 g8f6 b1c3 g7g6 g1f3 f8g7 f1e2 e8g8 e1g1 c7c6",
        "e2e4 d7d6 d2d4 g8f6 b1c3 g7g6 f2f4 f8g7 g1f3 e8g8 f1d3 b8a6",
        "e2e4 g7g6 d2d4 f8g7 b1c3 d7d6 f2f4 g8f6 g1f3 e8g8 f1d3",
        "e2e4 d7d5 e4d5 d8d5 b1c3 d5a5 d2d4 g8f6 g1f3 c7c6 f1c4 c8f5 c1d2 e7e6",
        "e2e4 d7d5 e4d5 g8f6 d2d4 f6d5 g1f3 c8g4 f1e2 e7e6 e1g1 f8e7 c2c4 d5b6",
        "e2e4 g8f6 e4e5 f6d5 d2d4 d7d6 g1f3 c8g4 f1e2 e7e6 e1g1 f8e7 c2c4 d5b6",
        "d2d4 d7d5 c2c4 e7e6 b1c3 g8f6 c1g5 f8e7 e2e3 e8g8 g1f3 h7h6 g5h4 b7b6",
        "d2d4 d7d5 c2c4 e7e6 b1c3 g8f6 c4d5 e6d5 c1g5 c7c6 e2e3 f8e7 f1d3 b8d7 d1c2 e8g8",
        "d2d4 d7d5 c2c4 d5c4 g1f3 g8f6 e2e3 e7e6 f1c4 c7c5 e1g1 a7a6",
        "d2d4 d7d5 c2c4 c7c6 g1f3 g8f6 b1c3 d5c4 a2a4 c8f5 e2e3 e7e6 f1c4 f8b4 e1g1 b8d7",
        "d2d4 d7d5 c2c4 c7c6 g1f3 g8f6 b1c3 e7e6 e2e3 b8d7 f1d3 d5c4 d3c4 b7b5 c4d3 a7a6 e3e4 c6c5",
        "d2d4 d7d5 c2c4 e7e5 d4e5 d5d4 g1f3 b8c6",
        "d2d4 g8f6 c2c4 g7g6 b1c3 f8g7 e2e4 d7d6 g1f3 e8g8 f1e2 e7e5 e1g1 b8c6 d4d5 c6e7",
        "d2d4 g8f6 c2c4 g7g6 b1c3 d7d5 c4d5 f6d5 e2e4 d5c3 b2c3 f8g7 f1c4 c7c5 g1e2 b8c6 c1e3 e8g8 e1g1",
        "d2d4 g8f6 c2c4 e7e6 b1c3 f8b4 e2e3 e8g8 f1d3 d7d5 g1f3 c7c5 e1g1 b8c6 a2a3 b4c3 b2c3 d5c4 d3c4 d8c7",
        "d2d4 g8f6 c2c4 e7e6 g1f3 b7b6 g2g3 c8b7 f1g2 f8e7 e1g1 e8g8 b1c3 f6e4",
        "d2d4 g8f6 c2c4 e7e6 g2g3 d7d5 f1g2 f8e7 g1f3 e8g8 e1g1 d5c4 d1c2 a7a6 c2c4 b7b5 c4c2 c8b7",
        "d2d4 g8f6 c2c4 c7c5 d4d5 e7e6 b1c3 e6d5 c4d5 d7d6 e2e4 g7g6 g1f3 f8g7 f1e2 e8g8 e1g1",
        "d2d4 f7f5 g2g3 g8f6 f1g2 g7g6 g1f3 f8g7 e1g1 e8g8 c2c4 d7d6",
        "d2d4 d7d5 g1f3 g8f6 c1f4 e7e6 e2e3 f8d6 f4g3 e8g8 f1d3 c7c5 b1d2 b8c6 c2c3",
        "d2d4 g8f6 g1f3 e7e6 c1f4 d7d5 e2e3 c7c5 c2c3 b8c6 b1d2 f8d6 f4g3 e8g8 f1d3",
        "d2d4 g8f6 c1g5 f6e4 g5f4 c7c5 f2f3 d8a5 c2c3 e4f6 d4d5",
        "d2d4 d7d5 g1f3 g8f6 e2e3 e7e6 f1d3 c7c5 b2b3 b8c6 e1g1 f8d6 c1b2 e8g8",
        "d2d4 d7d5 g1f3 g8f6 e2e3 c7c6 f1d3 c8g4",
        "d2d4 d7d5 b1c3 g8f6 c1g5 b8d7 f2f3",
        "d2d4 g8f6 g1f3 e7e6 c1g5 h7h6 g5h4 d7d5 e2e3 f8e7 b1d2 e8g8 f1d3 b7b6",
        "d2d4 g8f6 g1f3 g7g6 g2g3 f8g7 f1g2 e8g8 e1g1 d7d6 c2c4",
        "c2c4 e7e5 b1c3 g8f6 g1f3 b8c6 g2g3 d7d5 c4d5 f6d5 f1g2 d5b6 e1g1 f8e7",
        "c2c4 c7c5 g1f3 g8f6 b1c3 b8c6 g2g3 g7g6 f1g2 f8g7 e1g1 e8g8",
        "c2c4 e7e6 b1c3 d7d5 d2d4 g8f6 c1g5 f8e7 e2e3 e8g8 g1f3",
        "c2c4 c7c5 g1f3 g8f6 b1c3 e7e6 g2g3 b7b6 f1g2 c8b7 e1g1 f8e7",
        "g1f3 d7d5 g2g3 g8f6 f1g2 e7e6 e1g1 f8e7 d2d3 e8g8 b1d2 c7c5 e2e4 b8c6",
        "g1f3 g8f6 c2c4 g7g6 b1c3 f8g7 e2e4 d7d6 d2d4 e8g8 f1e2",
        "f2f4 d7d5 g1f3 g8f6 e2e3 g7g6 f1e2 f8g7 e1g1 e8g8 d2d3 c7c5",
        "b2b3 e7e5 c1b2 b8c6 e2e3 d7d5 f1b5 f8d6 f2f4 d8e7 g1f3 f7f6"
    )

    private val bookPositions: Set<String> by lazy {
        val set = HashSet<String>()
        for (line in bookLines) {
            val moves = line.split(" ")
            for (i in 1..moves.size) set.add(moves.subList(0, i).joinToString(" "))
        }
        set
    }

    fun isBook(movesSoFar: List<String>): Boolean = movesSoFar.isNotEmpty() && bookPositions.contains(movesSoFar.joinToString(" "))

    // ------------------------------------------------------------ the review itself

    /**
     * Rates the move that was played between [prev] (before the move) and [now] (after it).
     * [historyBefore] is the list of moves since the starting position, or null if we don't know it.
     * Returns null when the two boards are not exactly one move apart.
     */
    fun review(prev: Snapshot, now: Snapshot, historyBefore: List<String>?, given: DetectedMove? = null): Review? {
        val mv = given ?: detect(prev.grid, now.grid) ?: return null
        if (mv.white != prev.whiteToMove || now.whiteToMove == prev.whiteToMove) return null

        val before = score(prev.cp, prev.mate)
        val after = -score(now.cp, now.mate)
        val bestWin = winPercent(before)
        val afterWin = winPercent(after)
        val loss = max(0.0, bestWin - afterWin)
        val isBest = prev.best != null && prev.best == mv.uci
        val moveText = describe(prev.grid, mv.uci)

        // Did this move give material away? (value of what it took, minus what can be taken back for free)
        val movedNow = now.grid[mv.to]
        val gained = mv.captured?.let { value(it.type) } ?: 0
        val atRisk = if (movedNow != null && movedNow.type != PieceType.KING) captureGain(now.grid, mv.to) else 0
        val net = gained - atRisk

        val bestText = prev.best?.let { describe(prev.grid, it) }

        // Book moves
        if (historyBefore != null && isBook(historyBefore + mv.uci)) {
            return Review(mv.uci, mv.white, MoveRating.BOOK, moveText, "A well-known opening move.")
        }

        val rating: MoveRating
        val why: String
        if (isBest || loss <= 0.5) {
            val secondWin = if (prev.secondCp != null || prev.secondMate != null) winPercent(score(prev.secondCp, prev.secondMate)) else null
            if (isBest || loss <= 1.0) {
                if (net <= -2 && afterWin >= 40.0 && bestWin <= 92.0 && movedNow != null &&
                    movedNow.type != PieceType.PAWN
                ) {
                    rating = MoveRating.BRILLIANT
                    why = "You offered material (about $atRisk points can be taken) but the position is still good for you."
                } else if (isBest && secondWin != null && bestWin - secondWin >= 12.0 && bestWin >= 30.0) {
                    rating = MoveRating.GREAT
                    why = "This was the only move that kept your position strong. Other moves were much worse."
                } else {
                    rating = MoveRating.BEST
                    why = if (isBest) "This was Stockfish's top choice." else "As good as the best move."
                }
            } else {
                rating = MoveRating.BEST
                why = "As good as the best move."
            }
        } else {
            val pawns = (before - after).coerceIn(0, 1000) / 100.0
            val lostText = if (before - after >= 900) "a huge amount" else String.format(java.util.Locale.US, "about %.1f pawns", pawns)
            val betterText = if (bestText != null) " A better move was: $bestText." else ""
            when {
                loss <= 2.0 -> { rating = MoveRating.EXCELLENT; why = "Almost as good as the best move.$betterText" }
                loss <= 5.0 -> { rating = MoveRating.GOOD; why = "A fine move, but there was a slightly better one.$betterText" }
                else -> {
                    rating = when {
                        loss <= 10.0 -> MoveRating.INACCURACY
                        loss <= 20.0 -> MoveRating.MISTAKE
                        else -> MoveRating.BLUNDER
                    }
                    val reason = when {
                        before >= 9000 && after < 9000 -> "You missed a forced checkmate."
                        after <= -9000 -> "This allows a forced checkmate."
                        net <= -2 && movedNow != null -> "The ${pieceName(movedNow.type)} you moved can be taken for free, which costs you about $atRisk points."
                        else -> "You gave up $lostText of your advantage."
                    }
                    why = "$reason$betterText"
                }
            }
        }
        return Review(mv.uci, mv.white, rating, moveText, why)
    }
}
