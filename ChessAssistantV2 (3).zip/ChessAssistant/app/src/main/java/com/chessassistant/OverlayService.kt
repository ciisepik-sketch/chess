package com.chessassistant

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.chessassistant.views.ArrowOverlayView
import com.chessassistant.views.BoardSelectorView
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

class OverlayService : Service() {

    companion object {
        const val ACTION_START = "com.chessassistant.START"
        const val ACTION_STOP = "com.chessassistant.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL_ID = "assistant"
        private const val NOTIF_ID = 1
        private const val AUTO_INTERVAL_MS = 2000L

        @Volatile
        var running = false
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private lateinit var engine: StockfishEngine
    private lateinit var recognizer: BoardRecognizer

    private var projection: MediaProjection? = null
    private var capturer: ScreenCapturer? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())

    private var bubble: TextView? = null
    private var arrowView: ArrowOverlayView? = null
    private var panel: LinearLayout? = null
    private var panelStatus: TextView? = null
    private var selector: FrameLayout? = null

    private var busy = false
    private var autoJob: Job? = null
    private var lastPlacement: String? = null
    private var lastGrid: Grid? = null
    private var inferredWhiteToMove = true
    private var statusLine = "Tap the bubble to analyse the board."
    private val timeOptions = intArrayOf(500, 1000, 2000, 4000)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WindowManager::class.java)
        prefs = Prefs(this)
        engine = StockfishEngine(this)
        recognizer = BoardRecognizer(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        if (intent.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (intent.action == ACTION_START) {
            // Must be called promptly, and BEFORE getMediaProjection() on Android 10+
            startForegroundCompat()
            if (!running) {
                val code = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val data = readDataExtra(intent)
                if (data == null) { stopSelf(); return START_NOT_STICKY }
                val mpm = getSystemService(MediaProjectionManager::class.java)
                val proj = mpm.getMediaProjection(code, data)
                projection = proj
                capturer = ScreenCapturer(this, proj) { handler.post { stopSelf() } }
                capturer?.start()
                running = true
                buildUi()
                if (!engine.isAvailable()) {
                    toast("Stockfish binary not found in the APK. See README step 2.")
                }
            }
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readDataExtra(intent: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else intent.getParcelableExtra(EXTRA_DATA)

    override fun onDestroy() {
        running = false
        autoJob?.cancel()
        scope.cancel()
        handler.removeCallbacksAndMessages(null)
        removePanel()
        removeSelector()
        bubble?.let { safeRemove(it) }
        arrowView?.let { safeRemove(it) }
        capturer?.release()
        capturer = null
        projection = null
        engine.stop()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- notification

    @Suppress("DEPRECATION")
    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Chess Assistant", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("Chess Assistant is running")
            .setContentText("Tap the floating bubble to analyse the board")
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stop)
            .setOngoing(true)
            .build()
        startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    // ---------------------------------------------------------------- UI helpers

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    private fun safeRemove(v: View) { try { wm.removeView(v) } catch (_: Exception) { } }

    private fun overlayParams(w: Int, h: Int, touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
    }

    private fun boardRect(): RectF? {
        if (!prefs.hasBoard) return null
        val x = prefs.boardX.toFloat(); val y = prefs.boardY.toFloat(); val s = prefs.boardSize.toFloat()
        return RectF(x, y, x + s, y + s)
    }

    private fun buildUi() {
        val arrow = ArrowOverlayView(this)
        arrow.configure(boardRect(), prefs.whiteAtBottom)
        wm.addView(
            arrow,
            overlayParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, false)
        )
        arrowView = arrow
        createBubble()
    }

    private fun styleBubble(label: String, bg: Int, fg: Int, size: Float = 14f) {
        val tv = bubble ?: return
        tv.text = label
        tv.textSize = size
        tv.setTextColor(fg)
        tv.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(bg)
            setStroke(dp(3), 0xFFFF3D8B.toInt())
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createBubble() {
        val tv = TextView(this).apply {
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        bubble = tv
        styleBubble("\u265B", 0xFFE8478B.toInt(), Color.WHITE, 22f)
        val lp = overlayParams(dp(56), dp(56), true).apply { x = prefs.bubbleX; y = prefs.bubbleY }
        wm.addView(tv, lp)

        var startX = 0; var startY = 0
        var touchX = 0f; var touchY = 0f
        var moved = false; var longPressed = false
        val longPress = Runnable { longPressed = true; togglePanel() }
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y; touchX = e.rawX; touchY = e.rawY
                    moved = false; longPressed = false
                    handler.postDelayed(longPress, 500)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt(); val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) { moved = true; handler.removeCallbacks(longPress) }
                    if (moved) {
                        lp.x = startX + dx; lp.y = startY + dy
                        wm.updateViewLayout(tv, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longPress)
                    if (moved) { prefs.bubbleX = lp.x; prefs.bubbleY = lp.y }
                    else if (!longPressed) runOnce()
                    true
                }
                MotionEvent.ACTION_CANCEL -> { handler.removeCallbacks(longPress); true }
                else -> false
            }
        }
    }

    private fun setOverlaysVisible(visible: Boolean) {
        if (selector != null) return
        val v = if (visible) View.VISIBLE else View.INVISIBLE
        arrowView?.visibility = v
        bubble?.visibility = v
        panel?.visibility = v
    }

    private fun setStatus(s: String) {
        statusLine = s
        panelStatus?.text = s
    }

    // ---------------------------------------------------------------- menu panel

    private fun togglePanel() { if (panel != null) removePanel() else showPanel() }

    private fun removePanel() {
        panel?.let { safeRemove(it) }
        panel = null
        panelStatus = null
    }

    private fun sideLabel() = "Side to move: " + when (prefs.sideMode) {
        1 -> "White"; 2 -> "Black"; else -> "Auto (from last move)"
    }
    private fun boardLabel() = "Board: " + if (prefs.whiteAtBottom) "White at bottom" else "Black at bottom"
    private fun autoLabel() = "Auto-refresh: " + if (autoJob != null) "ON" else "OFF"
    private fun timeLabel() = "Think time: ${prefs.moveTimeMs / 1000.0}s"

    private fun showPanel() {
        if (panel != null) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply {
                setColor(0xF2FFF1F6.toInt()); cornerRadius = dp(20).toFloat(); setStroke(dp(2), 0xFFFF3D8B.toInt())
            }
        }
        val status = TextView(this).apply {
            setTextColor(0xFF3B0A2A.toInt()); textSize = 14f; text = statusLine
        }
        box.addView(status)
        panelStatus = status

        fun addButton(label: String, onClick: (Button) -> Unit): Button {
            val b = Button(this).apply {
                text = label; isAllCaps = false; textSize = 13f; setTextColor(0xFF3B0A2A.toInt()); background = GradientDrawable().apply { setColor(0xFFFFB6D0.toInt()); cornerRadius = dp(14).toFloat() }
                minHeight = 0; minimumHeight = dp(40)
                setOnClickListener { onClick(this) }
            }
            box.addView(
                b,
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    .apply { topMargin = dp(6) }
            )
            return b
        }

        addButton(sideLabel()) { b ->
            prefs.sideMode = (prefs.sideMode + 1) % 3
            lastPlacement = null
            b.text = sideLabel()
        }
        addButton(boardLabel()) { b ->
            prefs.whiteAtBottom = !prefs.whiteAtBottom
            arrowView?.configure(boardRect(), prefs.whiteAtBottom)
            arrowView?.setMove(null)
            lastPlacement = null; lastGrid = null
            b.text = boardLabel()
        }
        addButton(timeLabel()) { b ->
            val i = timeOptions.indexOf(prefs.moveTimeMs)
            prefs.moveTimeMs = timeOptions[(i + 1) % timeOptions.size]
            b.text = timeLabel()
        }
        addButton(autoLabel()) { b ->
            setAuto(autoJob == null)
            b.text = autoLabel()
            if (autoJob != null) removePanel()
        }
        addButton("Set board area") { startBoardSelection() }
        addButton("Learn pieces (board at start position)") { learnPieces() }
        addButton("Close menu") { removePanel() }
        addButton("Stop assistant") { stopSelf() }

        val lp = overlayParams(
            resources.displayMetrics.widthPixels - dp(32), WindowManager.LayoutParams.WRAP_CONTENT, true
        ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(24) }
        wm.addView(box, lp)
        panel = box
    }

    // ---------------------------------------------------------------- board area selection

    private fun startBoardSelection() {
        removePanel()
        if (selector != null) return
        bubble?.visibility = View.GONE
        val dm = resources.displayMetrics
        val initial = boardRect() ?: run {
            val s = dm.widthPixels * 0.92f
            RectF((dm.widthPixels - s) / 2f, dm.heightPixels * 0.25f, (dm.widthPixels + s) / 2f, dm.heightPixels * 0.25f + s)
        }
        val root = FrameLayout(this)
        val sel = BoardSelectorView(this, initial)
        root.addView(sel, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(0xEEFF8FB8.toInt())
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val save = Button(this).apply { text = "Save"; isAllCaps = false; setOnClickListener { finishSelection(sel, true) } }
        val cancel = Button(this).apply { text = "Cancel"; isAllCaps = false; setOnClickListener { finishSelection(sel, false) } }
        bar.addView(save, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(cancel, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(
            bar,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
                .apply { bottomMargin = dp(48) }
        )
        wm.addView(
            root,
            overlayParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, true)
        )
        selector = root
    }

    private fun removeSelector() {
        selector?.let { safeRemove(it) }
        selector = null
    }

    private fun finishSelection(sel: BoardSelectorView, save: Boolean) {
        if (save) {
            val r = sel.screenRect()
            prefs.boardX = r.left.roundToInt()
            prefs.boardY = r.top.roundToInt()
            prefs.boardSize = r.width().roundToInt()
            arrowView?.configure(boardRect(), prefs.whiteAtBottom)
            arrowView?.setMove(null)
            lastPlacement = null; lastGrid = null
            toast("Board area saved. Now use \"Learn pieces\" with the board at the starting position (once per piece theme).")
        }
        removeSelector()
        bubble?.visibility = View.VISIBLE
    }

    // ---------------------------------------------------------------- capture + analysis

    private suspend fun captureBoard(): Bitmap? {
        if (!prefs.hasBoard) {
            toast("Set the board area first (long-press the bubble > Set board area).")
            return null
        }
        val cap = capturer ?: return null
        var problem = "Screen capture failed."
        for (attempt in 1..3) {
            setOverlaysVisible(false)      // so our own arrow is not in the screenshot
            delay(if (attempt == 1) 180L else 700L)
            val full = cap.capture()
            setOverlaysVisible(true)
            if (full == null) { problem = "Screen capture failed."; continue }
            if (ScreenCapturer.isBlank(full)) {
                problem = "The screenshot came back completely black. Either this screen blocks screenshots, or capture was not ready. Tap again."
                full.recycle()
                continue
            }
            val x = prefs.boardX.coerceIn(0, full.width - 2)
            val y = prefs.boardY.coerceIn(0, full.height - 2)
            val size = minOf(prefs.boardSize, full.width - x, full.height - y)
            if (size < 64) {
                full.recycle()
                toast("Board area is outside the screen. Set it again.")
                return null
            }
            val crop = Bitmap.createBitmap(full, x, y, size, size)
            if (!ScreenCapturer.isBlank(crop)) {
                full.recycle()
                return crop
            }
            // The screen was captured, but the board area itself is black.
            problem = "The screen was captured, but the board area is black (board at $x,$y, size $size, on a ${full.width}x${full.height} screen). " +
                "This usually means the chess app blocks screen capture. A picture showing where I looked was saved in Pictures/ChessAssistant."
            if (attempt == 3) saveDebugScreenshot(full, x, y, size)
            crop.recycle()
            full.recycle()
        }
        toast(problem)
        return null
    }

    private fun runOnce() { scope.launch { cycle(true) } }

    private fun setAuto(on: Boolean) {
        autoJob?.cancel()
        autoJob = null
        if (on) {
            autoJob = scope.launch {
                while (isActive) {
                    cycle(false)
                    delay(AUTO_INTERVAL_MS)
                }
            }
        }
    }

    private fun resolveSide(grid: Grid): Boolean {
        val prev = lastGrid
        if (prev != null) {
            var changed = 0; var movedWhite = false; var movedBlack = false
            for (i in 0 until 64) {
                if (prev[i] != grid[i]) {
                    changed++
                    val now = grid[i]
                    if (now != null) { if (now.white) movedWhite = true else movedBlack = true }
                }
            }
            if (changed in 1..6 && movedWhite != movedBlack) inferredWhiteToMove = !movedWhite
        }
        lastGrid = grid
        return when (prefs.sideMode) { 1 -> true; 2 -> false; else -> inferredWhiteToMove }
    }

    private suspend fun cycle(user: Boolean) {
        if (busy) return
        busy = true
        try {
            val board = captureBoard() ?: return
            val whiteBottom = prefs.whiteAtBottom
            val grid = withContext(Dispatchers.Default) { recognizer.recognize(board, whiteBottom) }
            board.recycle()
            if (grid == null) {
                if (user) toast("Pieces not learned yet. Long-press the bubble > Learn pieces (with the board at the starting position).")
                return
            }
            val err = Fen.validate(grid)
            if (err != null) {
                styleBubble("?", 0xFFB3123F.toInt(), Color.WHITE, 22f)
                setStatus("Couldn't read the board: $err")
                if (user) toast("Couldn't read the board: $err")
                return
            }
            var whiteToMove = resolveSide(grid)
            val whiteInCheck = Rules.inCheck(grid, true)
            val blackInCheck = Rules.inCheck(grid, false)
            var sideProblem: String? = null
            if (whiteInCheck && blackInCheck) {
                sideProblem = "both kings are in check, so the board was probably misread"
            } else if (prefs.sideMode == 0) {
                // Only the side that is in check can be the one to move.
                if (whiteInCheck) whiteToMove = true
                if (blackInCheck) whiteToMove = false
            } else if ((whiteToMove && blackInCheck) || (!whiteToMove && whiteInCheck)) {
                sideProblem = "the side that is NOT to move is in check, so the side-to-move setting looks wrong"
            }
            if (sideProblem != null) {
                styleBubble("?", 0xFFB3123F.toInt(), Color.WHITE, 22f)
                setStatus("Couldn't read the board: $sideProblem")
                if (user) toast("Couldn't read the board: $sideProblem")
                return
            }
            val sideInCheck = if (whiteToMove) whiteInCheck else blackInCheck
            val key = Fen.placement(grid) + (if (whiteToMove) "w" else "b") + (if (whiteBottom) "1" else "0")
            if (!user && key == lastPlacement) return   // nothing changed

            lastPlacement = key
            arrowView?.setMove(null)
            styleBubble("\u2026", 0xFFE8478B.toInt(), Color.WHITE, 22f)
            val fen = Fen.build(grid, whiteToMove)
            val res = engine.analyse(fen, prefs.moveTimeMs)
            val move = res.bestMove?.let { Move.parse(it) }
            if (move == null) {
                val loser = if (whiteToMove) "White" else "Black"
                if (sideInCheck) {
                    styleBubble("\u2248[", 0xFF3B0A2A.toInt(), Color.WHITE, 20f)
                    setStatus("Checkmate! $loser is in check and has no moves left.")
                    if (user) toast("Checkmate!")
                } else {
                    styleBubble("=_=", 0xFFD7B8E8.toInt(), Color.BLACK, 18f)
                    setStatus("Draw (stalemate): $loser has no legal moves but is not in check.")
                    if (user) toast("Stalemate - it's a draw.")
                }
                return
            }
            arrowView?.setMove(move)
            showResult(whiteToMove, res.bestMove, res.cp, res.mate)
            if (sideInCheck) {
                styleBubble(":/", 0xFFFF6FA8.toInt(), Color.WHITE, 22f)
                setStatus("Check! " + statusLine)
            } else if (Rules.insufficientMaterial(grid)) {
                styleBubble("=_=", 0xFFD7B8E8.toInt(), Color.BLACK, 18f)
                setStatus("Draw: there aren't enough pieces left to checkmate.")
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            styleBubble("!", 0xFFB3123F.toInt(), Color.WHITE, 22f)
            toast(e.message ?: "Unexpected error")
            if (!user) { autoJob?.cancel(); autoJob = null }
        } finally {
            busy = false
            setOverlaysVisible(true)
        }
    }

    private fun showResult(whiteToMove: Boolean, best: String, cp: Int?, mate: Int?) {
        val wCp = cp?.let { if (whiteToMove) it else -it }
        val wMate = mate?.let { if (whiteToMove) it else -it }
        var label: String
        var bg: Int
        var fg: Int
        val who: String
        if (wMate != null) {
            label = if (wMate > 0) "+M$wMate" else "-M${abs(wMate)}"
            who = (if (wMate > 0) "White" else "Black") + " is winning (mate in ${abs(wMate)})"
            if (wMate > 0) { bg = Color.WHITE; fg = Color.BLACK } else { bg = 0xFF3B0A2A.toInt(); fg = Color.WHITE }
        } else {
            val c = wCp ?: 0
            val pawns = c / 100.0
            label = if (abs(pawns) >= 10) String.format(Locale.US, "%+.0f", pawns) else String.format(Locale.US, "%+.1f", pawns)
            who = when {
                abs(c) < 30 -> "Equal position"
                c > 0 && c >= 150 -> "White is clearly better"
                c > 0 -> "White is slightly better"
                c <= -150 -> "Black is clearly better"
                else -> "Black is slightly better"
            }
            when {
                c >= 30 -> { bg = Color.WHITE; fg = Color.BLACK }
                c <= -30 -> { bg = 0xFF3B0A2A.toInt(); fg = Color.WHITE }
                else -> { bg = 0xFFFFC2D9.toInt(); fg = Color.BLACK }
            }
        }
        styleBubble(label, bg, fg, 14f)
        setStatus("$who ($label) | best: $best | ${if (whiteToMove) "White" else "Black"} to move")
    }

    private fun saveDebugImage(b: Bitmap) {
        try {
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, "chess_debug_" + System.currentTimeMillis() + ".png")
                put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ChessAssistant")
            }
            val uri = contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return
            contentResolver.openOutputStream(uri)?.use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
        } catch (_: Exception) { }
    }

    /** Saves the whole screenshot with a red box where the board area is, so we can see what was captured. */
    private fun saveDebugScreenshot(full: Bitmap, x: Int, y: Int, size: Int) {
        try {
            val copy = full.copy(Bitmap.Config.ARGB_8888, true) ?: return
            val canvas = android.graphics.Canvas(copy)
            val paint = android.graphics.Paint().apply {
                color = 0xFFFF0000.toInt()
                style = android.graphics.Paint.Style.STROKE
                strokeWidth = 6f
            }
            canvas.drawRect(x.toFloat(), y.toFloat(), (x + size).toFloat(), (y + size).toFloat(), paint)
            saveDebugImage(copy)
            copy.recycle()
        } catch (_: Exception) { }
    }

    private fun learnPieces() {
        removePanel()
        scope.launch {
            if (busy) return@launch
            busy = true
            try {
                val board = captureBoard() ?: return@launch
                val whiteBottom = prefs.whiteAtBottom
                val err = withContext(Dispatchers.Default) { recognizer.learn(board, whiteBottom) }
                if (err != null) saveDebugImage(board)
                board.recycle()
                lastPlacement = null; lastGrid = null
                toast(err ?: "Pieces learned. Tap the bubble to analyse.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                toast(e.message ?: "Learning failed")
            } finally {
                busy = false
                setOverlaysVisible(true)
            }
        }
    }
}
