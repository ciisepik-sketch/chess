# Chess Assistant (Android 13, Kotlin)

Floating bubble -> screenshot of your chessboard -> piece recognition -> Stockfish -> green arrow + highlighted
destination square + evaluation. Intended for study and analysis (not for use in rated games against people).

## 1. Project layout
- `app/src/main/java/com/chessassistant/`
  - `MainActivity.kt` - enable/disable switch, permission flow, status checklist
  - `OverlayService.kt` - foreground service: bubble, menu, capture, recognition, engine, arrow
  - `ScreenCapturer.kt` - MediaProjection screenshots
  - `BoardRecognizer.kt` - silhouette-based board recognition (learns your piece set)
  - `StockfishEngine.kt` - runs Stockfish as a UCI child process
  - `Chess.kt` - pieces, FEN building, validation
  - `views/ArrowOverlayView.kt`, `views/BoardSelectorView.kt`
- `app/src/main/jniLibs/arm64-v8a/` - **put `libstockfish.so` here (step 2)**

## 2. Add the Stockfish engine (required, I could not bundle it)
1. Download the official Android build from https://github.com/official-stockfish/Stockfish/releases
   (asset named like `stockfish-android-armv8.tar`).
2. Extract it and copy the Stockfish executable to
   `app/src/main/jniLibs/arm64-v8a/libstockfish.so` (rename the file exactly like that).
   Android only lets apps execute files from the native-library folder, hence the `.so` name.
   `useLegacyPackaging = true` in `app/build.gradle.kts` makes Android extract it to disk.

## 3. Build the APK
1. Install Android Studio (current stable). Open the `ChessAssistant` folder, let Gradle sync
   (accept an AGP upgrade suggestion if offered).
2. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. APK: `app/build/outputs/apk/debug/app-debug.apk`.

## 4. Install on the UMIDIGI G5 Mecha
- USB: enable Developer options + USB debugging, then `adb install -r app-debug.apk`
- or copy the APK to the phone, open it, allow "install unknown apps" for your file manager.
- Settings > Battery: set Chess Assistant to "Unrestricted" so the vendor battery manager doesn't kill it.

## 5. Permissions
| Permission | Why |
|---|---|
| SYSTEM_ALERT_WINDOW (Display over other apps) | bubble, menu and arrow over other apps |
| Screen capture consent (system dialog, not a manifest permission) | screenshot the board |
| FOREGROUND_SERVICE (+ type mediaProjection) | Android requires it for screen capture |
| POST_NOTIFICATIONS | Android 13 notification for the foreground service (has a Stop button) |
No INTERNET permission: nothing leaves the phone.

## 6. Using it
1. Show the board in the **starting position** (analysis board works). Switch the assistant on.
2. Long-press bubble > **Set board area**: align the grid to the 64 squares > Save.
3. Long-press bubble > **Learn pieces** (once per piece theme/board size; set "Board" orientation first).
4. Tap the bubble to analyse. Menu: side to move (Auto/White/Black), orientation, think time, auto-refresh (2 s).
Bubble colour: white = White better, black = Black better, grey = equal; text is the eval in pawns (+M3 = mate in 3).

## 7. Known limits (honest list)
- Recognition is classical image processing, not a trained model. It needs a clean board: hide move hints,
  drawn arrows, and overlays from the chess app. Changing theme/board size means re-learning.
- Side to move cannot be seen on a screenshot: "Auto" infers it from the last position change; the first analysis
  assumes White. Use the manual setting when in doubt. En passant isn't known; castling rights are guessed from
  king/rook home squares.
- The overlay briefly hides (~0.2 s) during each capture so the arrow isn't read as part of the board; in
  auto-refresh mode you'll see a small flicker.
- Apps that block screenshots (FLAG_SECURE) show black frames and can't be read.
- Portrait orientation only. Screen capture uses MediaProjection per-session consent (target SDK 33).
