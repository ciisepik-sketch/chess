package com.chessassistant.views

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import com.chessassistant.Move
import kotlin.math.hypot

class ArrowOverlayView(context: Context) : View(context) {

    private var board: RectF? = null
    private var whiteAtBottom = true
    private var move: Move? = null
    private val path = Path()

    private var badgeFile = -1
    private var badgeRank = 0
    private var badgeText: String? = null
    private var badgeColor = 0

    private val destFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66FF3D8B }
    private val destStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFF3D8B.toInt(); style = Paint.Style.STROKE; strokeWidth = 6f
    }
    private val fromFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x33FF3D8B }
    private val arrowFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE6FF3D8B.toInt() }
    private val arrowEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 5f
        strokeJoin = Paint.Join.ROUND
    }
    private val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val badgeRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f
    }
    private val badgeTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
    }

    fun configure(board: RectF?, whiteAtBottom: Boolean) {
        this.board = board
        this.whiteAtBottom = whiteAtBottom
        invalidate()
    }

    fun setMove(m: Move?) {
        move = m
        invalidate()
    }

    /** Shows a small rating badge (like "??" or a star) on a square. Pass null text to remove it. */
    fun setBadge(file: Int, rank: Int, text: String?, color: Int) {
        badgeFile = file
        badgeRank = rank
        badgeText = text
        badgeColor = color
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val b = board ?: return
        val m = move
        val bt = badgeText
        if (m == null && bt == null) return
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        canvas.save()
        canvas.translate(-loc[0].toFloat(), -loc[1].toFloat())

        val sq = b.width() / 8f
        fun cx(file: Int) = b.left + ((if (whiteAtBottom) file else 7 - file) + 0.5f) * sq
        fun cy(rank: Int) = b.top + ((if (whiteAtBottom) 7 - rank else rank) + 0.5f) * sq

        if (m != null) {
            val x1 = cx(m.fromFile); val y1 = cy(m.fromRank)
            val x2 = cx(m.toFile); val y2 = cy(m.toRank)
            val h = sq / 2f

            canvas.drawRect(x1 - h, y1 - h, x1 + h, y1 + h, fromFill)
            canvas.drawRect(x2 - h, y2 - h, x2 + h, y2 + h, destFill)
            canvas.drawRect(x2 - h + 3f, y2 - h + 3f, x2 + h - 3f, y2 + h - 3f, destStroke)

            val dx = x2 - x1; val dy = y2 - y1
            val len = hypot(dx, dy)
            if (len > 1f) {
                val ux = dx / len; val uy = dy / len
                val nx = -uy; val ny = ux
                val sx = x1 + ux * sq * 0.18f; val sy = y1 + uy * sq * 0.18f
                val tipX = x2 - ux * sq * 0.10f; val tipY = y2 - uy * sq * 0.10f
                val headLen = sq * 0.42f
                val bx = tipX - ux * headLen; val by = tipY - uy * headLen
                val hw = sq * 0.07f
                val hh = sq * 0.22f
                path.reset()
                path.moveTo(sx + nx * hw, sy + ny * hw)
                path.lineTo(bx + nx * hw, by + ny * hw)
                path.lineTo(bx + nx * hh, by + ny * hh)
                path.lineTo(tipX, tipY)
                path.lineTo(bx - nx * hh, by - ny * hh)
                path.lineTo(bx - nx * hw, by - ny * hw)
                path.lineTo(sx - nx * hw, sy - ny * hw)
                path.close()
                canvas.drawPath(path, arrowEdge)
                canvas.drawPath(path, arrowFill)
            }
        }

        if (bt != null && badgeFile in 0..7 && badgeRank in 0..7) {
            val bcx = cx(badgeFile) + sq * 0.32f
            val bcy = cy(badgeRank) - sq * 0.32f
            val rad = sq * 0.22f
            badgePaint.color = badgeColor
            canvas.drawCircle(bcx, bcy, rad, badgePaint)
            canvas.drawCircle(bcx, bcy, rad, badgeRing)
            badgeTextPaint.textSize = rad * (if (bt.length > 1) 1.0f else 1.25f)
            val fm = badgeTextPaint.fontMetrics
            canvas.drawText(bt, bcx, bcy - (fm.ascent + fm.descent) / 2f, badgeTextPaint)
        }
        canvas.restore()
    }
}
