package com.chessassistant

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("chess_assistant", Context.MODE_PRIVATE)

    var boardX: Int
        get() = sp.getInt("board_x", 0)
        set(v) { sp.edit().putInt("board_x", v).apply() }
    var boardY: Int
        get() = sp.getInt("board_y", 0)
        set(v) { sp.edit().putInt("board_y", v).apply() }
    var boardSize: Int
        get() = sp.getInt("board_size", 0)
        set(v) { sp.edit().putInt("board_size", v).apply() }
    val hasBoard: Boolean get() = boardSize > 0

    var whiteAtBottom: Boolean
        get() = sp.getBoolean("white_bottom", true)
        set(v) { sp.edit().putBoolean("white_bottom", v).apply() }

    /** 0 = auto-detect from last move, 1 = White to move, 2 = Black to move */
    var sideMode: Int
        get() = sp.getInt("side_mode", 0)
        set(v) { sp.edit().putInt("side_mode", v).apply() }

    var moveTimeMs: Int
        get() = sp.getInt("move_time", 1000)
        set(v) { sp.edit().putInt("move_time", v).apply() }

    var bubbleX: Int
        get() = sp.getInt("bubble_x", 16)
        set(v) { sp.edit().putInt("bubble_x", v).apply() }
    var bubbleY: Int
        get() = sp.getInt("bubble_y", 400)
        set(v) { sp.edit().putInt("bubble_y", v).apply() }
}
