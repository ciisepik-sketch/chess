package com.chessassistant

import android.content.Context
import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.BufferedWriter
import java.io.File
import java.io.IOException
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Runs the Stockfish executable as a child process and talks UCI to it.
 * The executable must be packaged as app/src/main/jniLibs/arm64-v8a/libstockfish.so
 * (Android only allows executing files from the app's native library directory).
 *
 * Fixes compared with the old version:
 *  - Notices straight away if Stockfish crashed or was killed by Android
 *    (before, the app just waited for the whole timeout and said "timed out").
 *  - Checks the position is sane before sending it (Stockfish can crash on
 *    impossible positions such as a missing king).
 *  - Syncs with the engine (isready) before every search so old output can
 *    never be mistaken for the new answer.
 *  - Restarts Stockfish and retries once if it died.
 *  - Asks Stockfish to stop politely before giving up on a slow search.
 *  - Error messages now say what really happened.
 */
class StockfishEngine(private val context: Context) {

    /** secondCp / secondMate describe the engine's second-best move (only filled in when 2 lines were asked for). */
    data class Result(
        val bestMove: String?, val cp: Int?, val mate: Int?,
        val secondCp: Int? = null, val secondMate: Int? = null
    )

    private companion object {
        const val EOF_MARKER = "<<engine-output-closed>>"
        const val THREADS = 2
        const val HASH_MB = 32
    }

    private var process: Process? = null
    private var writer: BufferedWriter? = null
    private var lines = LinkedBlockingQueue<String>()
    private val mutex = Mutex()
    private val recent = ArrayDeque<String>()
    private var multiPv = 1

    private val binary: File get() = File(context.applicationInfo.nativeLibraryDir, "libstockfish.so")

    fun isAvailable(): Boolean = binary.exists()

    private fun send(cmd: String) {
        val w = writer ?: throw IOException("Engine not running")
        try {
            w.write(cmd); w.write("\n"); w.flush()
        } catch (e: IOException) {
            throw IOException("Stockfish stopped unexpectedly (could not send a command)")
        }
    }

    private fun note(line: String) {
        recent.addLast(line)
        while (recent.size > 5) recent.removeFirst()
    }

    private fun lastOutput(): String =
        if (recent.isEmpty()) "no output" else recent.last().take(120)

    private class EngineDied : IOException("Stockfish stopped unexpectedly")

    /** Waits for a line starting with [prefix]. Returns null on timeout, throws EngineDied if the process ended. */
    private fun waitFor(prefix: String, timeoutMs: Long, onLine: ((String) -> Unit)? = null): String? {
        val q = lines
        val deadline = SystemClock.elapsedRealtime() + timeoutMs
        while (true) {
            val remaining = deadline - SystemClock.elapsedRealtime()
            if (remaining <= 0) return null
            val line = q.poll(remaining, TimeUnit.MILLISECONDS) ?: return null
            if (line == EOF_MARKER) throw EngineDied()
            note(line)
            onLine?.invoke(line)
            if (line.startsWith(prefix)) return line
        }
    }

    private fun ensureStarted() {
        if (process?.isAlive == true) return
        stop()
        if (!binary.exists()) {
            throw IOException("Stockfish binary missing. Copy it to app/src/main/jniLibs/arm64-v8a/libstockfish.so and rebuild (see README).")
        }
        // Each engine process gets its own queue, so a dead process can never add old lines to a new one.
        val q = LinkedBlockingQueue<String>()
        lines = q
        recent.clear()
        val p = ProcessBuilder(binary.absolutePath).redirectErrorStream(true).start()
        process = p
        multiPv = 1
        writer = p.outputStream.bufferedWriter()
        Thread {
            try {
                p.inputStream.bufferedReader().forEachLine { q.put(it) }
            } catch (_: Exception) { }
            q.put(EOF_MARKER)
        }.apply { isDaemon = true }.start()

        send("uci")
        if (waitFor("uciok", 10_000) == null) { stop(); throw IOException("Stockfish did not respond to UCI") }
        send("setoption name Threads value $THREADS")
        send("setoption name Hash value $HASH_MB")
        send("isready")
        if (waitFor("readyok", 10_000) == null) { stop(); throw IOException("Stockfish did not become ready") }
    }

    /**
     * Basic safety check. Stockfish does not check positions itself and can crash or hang on
     * impossible ones, which is what a wrongly recognised board can produce.
     * Returns null if the position looks fine, otherwise a short reason.
     */
    private fun fenProblem(fen: String): String? {
        val parts = fen.trim().split(Regex("\\s+"))
        if (parts.size < 2) return "position is incomplete"
        val rows = parts[0].split("/")
        if (rows.size != 8) return "position does not have 8 rows"
        var whiteKings = 0
        var blackKings = 0
        val kingSquares = mutableMapOf<Char, Pair<Int, Int>>()
        for ((r, row) in rows.withIndex()) {
            var file = 0
            for (ch in row) {
                if (ch.isDigit()) {
                    file += ch - '0'
                } else {
                    if (ch == 'K') { whiteKings++; kingSquares['K'] = Pair(file, r) }
                    if (ch == 'k') { blackKings++; kingSquares['k'] = Pair(file, r) }
                    if ((ch == 'P' || ch == 'p') && (r == 0 || r == 7)) return "a pawn is on the first or last row"
                    file++
                }
            }
            if (file != 8) return "a row does not add up to 8 squares"
        }
        if (whiteKings != 1 || blackKings != 1) return "needs exactly one king of each colour (found $whiteKings white, $blackKings black)"
        val wk = kingSquares['K']!!
        val bk = kingSquares['k']!!
        if (Math.abs(wk.first - bk.first) <= 1 && Math.abs(wk.second - bk.second) <= 1) return "the two kings are touching"
        return null
    }

    /** Scores in the result are from the point of view of the side to move. */
    suspend fun analyse(fen: String, moveTimeMs: Int, pvCount: Int = 1): Result = mutex.withLock {
        withContext(Dispatchers.IO) {
            val problem = fenProblem(fen)
            if (problem != null) throw IOException("Board not recognised properly: $problem")
            try {
                searchOnce(fen, moveTimeMs, pvCount)
            } catch (e: EngineDied) {
                // Stockfish crashed or Android killed it. Start a fresh one and try once more.
                stop()
                try {
                    searchOnce(fen, moveTimeMs, pvCount)
                } catch (e2: EngineDied) {
                    stop()
                    throw IOException("Stockfish keeps stopping (last output: ${lastOutput()})")
                }
            }
        }
    }

    private fun searchOnce(fen: String, moveTimeMs: Int, pvCount: Int): Result {
        ensureStarted()

        // Sync with the engine so nothing left over from an earlier search is read as the new answer.
        send("isready")
        if (waitFor("readyok", 5_000) == null) {
            stop()
            throw IOException("Stockfish stopped responding (last output: ${lastOutput()})")
        }
        if (pvCount != multiPv) {
            send("setoption name MultiPV value $pvCount")
            multiPv = pvCount
            send("isready")
            if (waitFor("readyok", 5_000) == null) {
                stop()
                throw IOException("Stockfish stopped responding (last output: ${lastOutput()})")
            }
        }
        lines.clear()

        var cp: Int? = null
        var mate: Int? = null
        var cp2: Int? = null
        var mate2: Int? = null
        val onLine: (String) -> Unit = { l ->
            if (l.startsWith("info") && l.contains(" score ") && !l.contains("bound")) {
                val t = l.split(" ")
                val i = t.indexOf("score")
                val v = t.getOrNull(i + 2)?.toIntOrNull()
                val pvAt = t.indexOf("multipv")
                val which = if (pvAt >= 0) (t.getOrNull(pvAt + 1)?.toIntOrNull() ?: 1) else 1
                if (i >= 0 && v != null) {
                    val kind = t.getOrNull(i + 1)
                    if (which == 1) {
                        if (kind == "cp") { cp = v; mate = null }
                        else if (kind == "mate") { mate = v; cp = null }
                    } else if (which == 2) {
                        if (kind == "cp") { cp2 = v; mate2 = null }
                        else if (kind == "mate") { mate2 = v; cp2 = null }
                    }
                }
            }
        }

        send("ucinewgame")
        send("position fen $fen")
        send("go movetime $moveTimeMs")

        var end = waitFor("bestmove", moveTimeMs + 8000L, onLine)
        if (end == null) {
            // Search overran: ask it to stop and give it a moment to answer before giving up.
            try { send("stop") } catch (_: Exception) { }
            end = waitFor("bestmove", 3000L, onLine)
        }
        if (end == null) {
            val why = lastOutput()
            stop()
            throw IOException("Stockfish did not answer in time (last output: $why)")
        }
        val best = end.split(" ").getOrNull(1)
        return Result(if (best == null || best == "(none)" || best == "0000") null else best, cp, mate, cp2, mate2)
    }

    fun stop() {
        try { writer?.let { it.write("quit\n"); it.flush() } } catch (_: Exception) { }
        try { process?.destroy() } catch (_: Exception) { }
        process = null
        writer = null
    }
}
