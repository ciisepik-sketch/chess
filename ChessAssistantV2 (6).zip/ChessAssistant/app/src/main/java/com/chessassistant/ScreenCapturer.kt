package com.chessassistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.view.WindowManager
import kotlinx.coroutines.delay

/** Keeps one virtual display running and always holds the newest frame. */
class ScreenCapturer(
    private val context: Context,
    private val projection: MediaProjection,
    onStopped: () -> Unit
) {
    companion object {
        fun isBlank(b: Bitmap): Boolean {
            for (iy in 1..20) for (ix in 1..20) {
                val p = b.getPixel(b.width * ix / 21, b.height * iy / 21)
                if ((p and 0x00FFFFFF) != 0) return false
            }
            return true
        }
    }

    private val thread = HandlerThread("screen-capture").apply { start() }
    private val handler = Handler(thread.looper)
    private val lock = Any()
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var held: Image? = null
    private var frames = 0L
    private var w = 0
    private var h = 0
    private var dpi = 0
    @Volatile private var released = false

    init {
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { onStopped() }
        }, handler)
    }

    fun start() {
        synchronized(lock) {
            if (released || display != null) return
            val wm = context.getSystemService(WindowManager::class.java)
            val b = wm.maximumWindowMetrics.bounds
            w = b.width(); h = b.height()
            dpi = context.resources.displayMetrics.densityDpi
            val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
            r.setOnImageAvailableListener({ rd ->
                val img = try { rd.acquireLatestImage() } catch (e: Exception) { null }
                if (img != null) {
                    synchronized(lock) {
                        if (released) {
                            img.close()
                        } else {
                            try { held?.close() } catch (_: Exception) { }
                            held = img
                            frames++
                        }
                    }
                }
            }, handler)
            reader = r
            display = projection.createVirtualDisplay(
                "chess-capture", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                r.surface, null, handler
            )
        }
    }

    private fun restartDisplay() {
        synchronized(lock) {
            try { display?.release() } catch (_: Exception) { }
            display = null
            try { held?.close() } catch (_: Exception) { }
            held = null
            try { reader?.close() } catch (_: Exception) { }
            reader = null
            frames = 0
        }
        start()
    }

    suspend fun capture(): Bitmap? {
        start()
        var t0 = SystemClock.elapsedRealtime()
        val deadline = t0 + 4500
        var seen = -1L
        var last: Bitmap? = null
        var blankStart = 0L
        var restarts = 0
        while (SystemClock.elapsedRealtime() < deadline) {
            val now = SystemClock.elapsedRealtime()
            val count = synchronized(lock) { frames }
            if (count > 0 && count != seen) {
                seen = count
                val bmp = synchronized(lock) {
                    held?.let { try { toBitmap(it) } catch (e: Exception) { null } }
                }
                if (bmp != null) {
                    if (!isBlank(bmp)) { last?.recycle(); return bmp }
                    last?.recycle()
                    last = bmp
                    if (blankStart == 0L) blankStart = now
                }
            }
            val noFrames = count == 0L && now - t0 > 1500
            val stuckBlank = blankStart != 0L && now - blankStart > 900
            if ((noFrames || stuckBlank) && restarts < 2) {
                restarts++
                restartDisplay()
                seen = -1L
                blankStart = 0L
                t0 = SystemClock.elapsedRealtime()
            }
            delay(120)
        }
        return last
    }

    private fun toBitmap(img: Image): Bitmap {
        val plane = img.planes[0]
        val pixelStride = plane.pixelStride
        val rowPadding = plane.rowStride - pixelStride * w
        val padded = Bitmap.createBitmap(w + rowPadding / pixelStride, h, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(plane.buffer)
        val out = if (padded.width == w) padded
        else Bitmap.createBitmap(padded, 0, 0, w, h).also { padded.recycle() }
        out.setHasAlpha(false)
        return out
    }

    fun release() {
        released = true
        synchronized(lock) {
            try { display?.release() } catch (_: Exception) { }
            try { held?.close() } catch (_: Exception) { }
            try { reader?.close() } catch (_: Exception) { }
            display = null; held = null; reader = null
        }
        try { projection.stop() } catch (_: Exception) { }
        thread.quitSafely()
    }
}
