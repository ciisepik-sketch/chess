package com.chessassistant

enum class PieceType(val letter: Char) {
    PAWN('p'), KNIGHT('n'), BISHOP('b'), ROOK('r'), QUEEN('q'), KING('k')
}

data class Piece(val type: PieceType, val white: Boolean) {
    fun fenChar(): Char = if (white) type.letter.uppercaseChar() else type.letter
}

/** Index = rank * 8 + file. rank 0 = rank "1", file 0 = file "a". */
typealias Grid = Array<Piece?>

data class Move(val fromFile: Int, val fromRank: Int, val toFile: Int, val toRank: Int) {
    companion object {
        fun parse(uci: String): Move? {
            if (uci.length < 4) return null
            val m = Move(uci[0] - 'a', uci[1] - '1', uci[2] - 'a', uci[3] - '1')
            val all = intArrayOf(m.fromFile, m.fromRank, m.toFile, m.toRank)
            return if (all.all { it in 0..7 }) m else null
        }
    }
}

object Fen {
    fun placement(grid: Grid): String {
        val sb = StringBuilder()
        for (rank in 7 downTo 0) {
            var empty = 0
            for (file in 0..7) {
                val p = grid[rank * 8 + file]
                if (p == null) {
                    empty++
                } else {
                    if (empty > 0) { sb.append(empty); empty = 0 }
                    sb.append(p.fenChar())
                }
            }
            if (empty > 0) sb.append(empty)
            if (rank > 0) sb.append('/')
        }
        return sb.toString()
    }

    fun build(grid: Grid, whiteToMove: Boolean): String {
        fun at(file: Int, rank: Int) = grid[rank * 8 + file]
        val castling = StringBuilder()
        if (at(4, 0) == Piece(PieceType.KING, true)) {
            if (at(7, 0) == Piece(PieceType.ROOK, true)) castling.append('K')
            if (at(0, 0) == Piece(PieceType.ROOK, true)) castling.append('Q')
        }
        if (at(4, 7) == Piece(PieceType.KING, false)) {
            if (at(7, 7) == Piece(PieceType.ROOK, false)) castling.append('k')
            if (at(0, 7) == Piece(PieceType.ROOK, false)) castling.append('q')
        }
        if (castling.isEmpty()) castling.append('-')
        return "${placement(grid)} ${if (whiteToMove) "w" else "b"} $castling - 0 1"
    }

    /** Returns an error message if the position can't be legal, else null. */
    fun validate(grid: Grid): String? {
        val whiteKings = grid.count { it != null && it.type == PieceType.KING && it.white }
        val blackKings = grid.count { it != null && it.type == PieceType.KING && !it.white }
        if (whiteKings != 1 || blackKings != 1) return "expected one king per side (found $whiteKings white, $blackKings black)"
        for (i in 0..7) {
            val a = grid[i]; val b = grid[56 + i]
            if (a != null && a.type == PieceType.PAWN) return "pawn on the first rank"
            if (b != null && b.type == PieceType.PAWN) return "pawn on the last rank"
        }
        return null
    }
}


/** Simple board rules used for the bubble faces (check, checkmate, draw). */
object Rules {
    private fun at(grid: Grid, file: Int, rank: Int): Piece? =
        if (file in 0..7 && rank in 0..7) grid[rank * 8 + file] else null

    /** Is the king of the given colour attacked right now? */
    fun inCheck(grid: Grid, white: Boolean): Boolean {
        var kf = -1
        var kr = -1
        for (i in 0..63) {
            val p = grid[i]
            if (p != null && p.type == PieceType.KING && p.white == white) { kf = i % 8; kr = i / 8 }
        }
        if (kf < 0) return false
        return attacked(grid, kf, kr, !white)
    }

    private fun attacked(grid: Grid, f: Int, r: Int, byWhite: Boolean): Boolean {
        // Pawns
        val pawnRank = if (byWhite) r - 1 else r + 1
        for (df in intArrayOf(-1, 1)) {
            val p = at(grid, f + df, pawnRank)
            if (p != null && p.white == byWhite && p.type == PieceType.PAWN) return true
        }
        // Knights
        val jumps = arrayOf(
            intArrayOf(1, 2), intArrayOf(2, 1), intArrayOf(-1, 2), intArrayOf(-2, 1),
            intArrayOf(1, -2), intArrayOf(2, -1), intArrayOf(-1, -2), intArrayOf(-2, -1)
        )
        for (j in jumps) {
            val p = at(grid, f + j[0], r + j[1])
            if (p != null && p.white == byWhite && p.type == PieceType.KNIGHT) return true
        }
        // The other king
        for (df in -1..1) for (dr in -1..1) {
            if (df == 0 && dr == 0) continue
            val p = at(grid, f + df, r + dr)
            if (p != null && p.white == byWhite && p.type == PieceType.KING) return true
        }
        // Rooks, bishops and queens (they slide until something is in the way)
        for (df in -1..1) for (dr in -1..1) {
            if (df == 0 && dr == 0) continue
            val straight = df == 0 || dr == 0
            var cf = f + df
            var cr = r + dr
            while (cf in 0..7 && cr in 0..7) {
                val p = grid[cr * 8 + cf]
                if (p != null) {
                    if (p.white == byWhite) {
                        if (p.type == PieceType.QUEEN) return true
                        if (straight && p.type == PieceType.ROOK) return true
                        if (!straight && p.type == PieceType.BISHOP) return true
                    }
                    break
                }
                cf += df
                cr += dr
            }
        }
        return false
    }

    /** Does the given side have at least one legal move? (Ignores castling and en passant, which can't be seen on a screenshot.) */
    fun hasLegalMove(grid: Grid, white: Boolean): Boolean {
        for (from in 0..63) {
            val p = grid[from]
            if (p == null || p.white != white) continue
            val f = from % 8
            val r = from / 8
            val targets = ArrayList<Int>()

            fun tryAdd(tf: Int, tr: Int, mustCapture: Boolean, mustBeEmpty: Boolean) {
                if (tf !in 0..7 || tr !in 0..7) return
                val t = grid[tr * 8 + tf]
                if (t != null && t.white == white) return
                if (mustCapture && t == null) return
                if (mustBeEmpty && t != null) return
                targets.add(tr * 8 + tf)
            }

            when (p.type) {
                PieceType.PAWN -> {
                    val dir = if (white) 1 else -1
                    val startRank = if (white) 1 else 6
                    if (r + dir in 0..7 && grid[(r + dir) * 8 + f] == null) {
                        targets.add((r + dir) * 8 + f)
                        if (r == startRank && grid[(r + 2 * dir) * 8 + f] == null) targets.add((r + 2 * dir) * 8 + f)
                    }
                    tryAdd(f - 1, r + dir, true, false)
                    tryAdd(f + 1, r + dir, true, false)
                }
                PieceType.KNIGHT -> {
                    val jumps = arrayOf(
                        intArrayOf(1, 2), intArrayOf(2, 1), intArrayOf(-1, 2), intArrayOf(-2, 1),
                        intArrayOf(1, -2), intArrayOf(2, -1), intArrayOf(-1, -2), intArrayOf(-2, -1)
                    )
                    for (j in jumps) tryAdd(f + j[0], r + j[1], false, false)
                }
                PieceType.KING -> {
                    for (df in -1..1) for (dr in -1..1) {
                        if (df == 0 && dr == 0) continue
                        tryAdd(f + df, r + dr, false, false)
                    }
                }
                else -> {
                    for (df in -1..1) for (dr in -1..1) {
                        if (df == 0 && dr == 0) continue
                        val straight = df == 0 || dr == 0
                        if (p.type == PieceType.ROOK && !straight) continue
                        if (p.type == PieceType.BISHOP && straight) continue
                        var cf = f + df
                        var cr = r + dr
                        while (cf in 0..7 && cr in 0..7) {
                            val t = grid[cr * 8 + cf]
                            if (t != null && t.white == white) break
                            targets.add(cr * 8 + cf)
                            if (t != null) break
                            cf += df
                            cr += dr
                        }
                    }
                }
            }

            for (to in targets) {
                val copy = grid.copyOf()
                copy[to] = copy[from]
                copy[from] = null
                if (!inCheck(copy, white)) return true
            }
        }
        return false
    }

    /** True when neither side has enough pieces to ever checkmate (bare kings, or one minor piece). */
    fun insufficientMaterial(grid: Grid): Boolean {
        val others = grid.filter { it != null && it.type != PieceType.KING }
        if (others.isEmpty()) return true
        if (others.size == 1) {
            val t = others[0]!!.type
            return t == PieceType.KNIGHT || t == PieceType.BISHOP
        }
        return false
    }
}


/** Shown at the top right of the app screen and in the bubble menu, so you can tell which build is installed. */
object AppInfo {
    const val VERSION = "v4"
}
