plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.chessassistant"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.chessassistant"
        minSdk = 30
        targetSdk = 33          // Android 13
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += "arm64-v8a" }   // the Stockfish binary is arm64 only
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Sign release builds with the debug key so the APK installs without extra setup.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    // REQUIRED: extracts libstockfish.so to disk so Android lets us execute it as a process.
    packaging { jniLibs { useLegacyPackaging = true } }

    lint { abortOnError = false }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.activity:activity-ktx:1.8.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
}
