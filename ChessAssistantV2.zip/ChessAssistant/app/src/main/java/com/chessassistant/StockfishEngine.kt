package com.chessassistant

import android.content.Context
import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.BufferedWriter
import java.io.File
import java.io.IOException
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

class StockfishEngine(private val context: Context) {

    data class Result(val bestMove: String?, val cp: Int?, val mate: Int?)

    private var process: Process? = null
    private var writer: BufferedWriter? = null
    private val lines = LinkedBlockingQueue<String>()
    private val recent = ArrayDeque<String>()
    private val mutex = Mutex()

    private val binary: File get() = File(context.applicationInfo.nativeLibraryDir, "libstockfish.so")

    fun isAvailable(): Boolean = binary.exists()

    private fun remember(l: String) {
        synchronized(recent) {
            recent.addLast(l)
            while (recent.size > 8) recent.removeFirst()
        }
    }

    private fun recentText(): String = synchronized(recent) { recent.joinToString(" | ").take(400) }

    private fun exitInfo(p: Process?): String =
        if (p == null) "no process" else try { "exited with code ${p.exitValue()}" } catch (e: IllegalThreadStateException) { "still running" }

    private fun send(cmd: String) {
        val w = writer ?: throw IOException("Engine not running")
        w.write(cmd); w.write("\n"); w.flush()
    }

    private fun waitFor(prefix: String, timeoutMs: Long, onLine: ((String) -> Unit)? = null): String? {
        val deadline = SystemClock.elapsedRealtime() + timeoutMs
        while (true) {
            val remaining = deadline - SystemClock.elapsedRealtime()
            if (remaining <= 0) return null
            val line = lines.poll(minOf(remaining, 250L), TimeUnit.MILLISECONDS)
            if (line == null) {
                if (process?.isAlive != true) return null
                continue
            }
            remember(line)
            onLine?.invoke(line)
            if (line.startsWith(prefix)) return line
        }
    }

    private fun ensureStarted() {
        if (process?.isAlive == true) return
        if (!binary.exists()) {
            throw IOException("Stockfish binary missing from the APK.")
        }
        lines.clear()
        synchronized(recent) { recent.clear() }
        val p = ProcessBuilder(binary.absolutePath).redirectErrorStream(true).start()
        process = p
        writer = p.outputStream.bufferedWriter()
        Thread {
            try { p.inputStream.bufferedReader().forEachLine { lines.put(it) } } catch (_: Exception) { }
        }.apply { isDaemon = true }.start()

        send("uci")
        if (waitFor("uciok", 10_000) == null) {
            val why = "Stockfish did not answer 'uci' (${exitInfo(p)}). Output: ${recentText()}"
            stop(); throw IOException(why)
        }
        send("setoption name Threads value 2")
        send("setoption name Hash value 32")
        send("isready")
        if (waitFor("readyok", 10_000) == null) {
            val why = "Stockfish did not become ready (${exitInfo(p)}). Output: ${recentText()}"
            stop(); throw IOException(why)
        }
    }

    /** Scores are from the point of view of the side to move. */
    suspend fun analyse(fen: String, moveTimeMs: Int): Result = mutex.withLock {
        withContext(Dispatchers.IO) {
            ensureStarted()
            lines.clear()
            synchronized(recent) { recent.clear() }
            var cp: Int? = null
            var mate: Int? = null
            val parse: (String) -> Unit = { l ->
                if (l.startsWith("info") && l.contains(" score ") && !l.contains("bound")) {
                    val t = l.split(" ")
                    val i = t.indexOf("score")
                    val v = t.getOrNull(i + 2)?.toIntOrNull()
                    if (i >= 0 && v != null) {
                        when (t.getOrNull(i + 1)) {
                            "cp" -> { cp = v; mate = null }
                            "mate" -> { mate = v; cp = null }
                        }
                    }
                }
            }
            send("position fen $fen")
            send("go movetime $moveTimeMs")
            var end = waitFor("bestmove", moveTimeMs + 3000L, parse)
            if (end == null && process?.isAlive == true) {
                send("stop")
                end = waitFor("bestmove", 4000L, parse)
            }
            val line = end ?: run {
                val why = "Stockfish gave no answer (${exitInfo(process)}). FEN: $fen. Last output: ${recentText()}"
                stop()
                throw IOException(why)
            }
            val best = line.split(" ").getOrNull(1)
            Result(if (best == null || best == "(none)" || best == "0000") null else best, cp, mate)
        }
    }

    fun stop() {
        try { writer?.let { it.write("quit\n"); it.flush() } } catch (_: Exception) { }
        try { process?.destroy() } catch (_: Exception) { }
        process = null
        writer = null
    }
}
